(* ::Package:: *){"dataaccess",{"Data","Cicy3","Cicy3Sym"},"How to access data from the package data sets."}
{"bicubic1",{"CIProp","bicubic","Sec","threefold","CY"},"Compute triple intersection numbers for bicubic CY."}
{"bicubic1new",{"CIProp","bicubic","Sec","threefold","CY"},"Compute triple intersection numbers for bicubic CY."}
{"tetraquadric1",{"CIProp","tetraquadric","C","threefold","CY"},"Compute Chern class of tangent bundle for tetraquadric CY."}
{"symmetry1",{"CIProp","Order","Group","ProjOrder","ProjGroup","symmetry"},"Define a simple group via its generators and compute its order"}
{"CIsymmetry",{"CIProp","DefEqs","threefold","symmetry"},"Find defining equations for a tetra-quadric with a Z2xZ2 symmetry"}
{"tetraquadriclbs",{"CIProp","tetraquadric","LBS","IndLBS"},"Compute index of a line bundle of the tetra-quadric CY."}
