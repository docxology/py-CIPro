(* ::Package:: *)

(* ::Title:: *)
(*CIPro package, v1.0*)


(* ::Text:: *)
(*Authors: Andre Lukas, James Gray, Lara Anderson, Andrei Constantin,  Yang-Hui He, Seung-Joo Lee*)


(* ::Section::Closed:: *)
(*Start package*)


BeginPackage["CIPro`"];


(* ::Section::Closed:: *)
(*Documentation*)


(* ::Subsection::Closed:: *)
(*General help*)


CIPro::usage="The CIPro package provides tools and data for coputing with complete intersection (CI) manifolds in products of projective spaces.\n"<>
"\[FilledSmallSquare] Basic help can be obtained by executing CIPro[], CIPro[\"Long\"] or CIPro[\"Manual\"].\n"<>
"\[FilledSmallSquare] Mathematical structures are represented by associations.\n"<>
"\[FilledSmallSquare] Associations can represent CIs, matrix groups, CIs and symmetries, CIs and line bundle sums.\n"<>
"\[FilledSmallSquare] Examples for how to use the package can be accessed by executing CIExample[].\n"<>
"\[FilledSmallSquare] Data, SaveData and DeleteData are the main modules to access package data (see Data[], SaveData[] and DeleteData[]).\n"<>
"\[FilledSmallSquare] The main module to compute properties of CIs is CIProp (see CIProp[] or CIPro[\"Long\"]).\n"<>
"\[FilledSmallSquare] The main module to compute modifications of CIs is CIMod (see CIMod[] or CIMod[\"Long\"]).\n"<>
"\[FilledSmallSquare] The package has a number of system and auxiliary modules, see ?CISystemModules.";


(* ::Subsection::Closed:: *)
(*Messages*)


CIPro::dirmissing="Data directory not found. Check global option \"DataPath\".";
CIPro::datamissing="Data set `1` not found.";
CIPro::listbounds="Index out of bounds. Index for data set `1` ranges from 1 to `2`."
CIPro::keymiss="Key(s) `1` missing from association.";
CIPro::keycomp="Keys not yet computed: `1`";
CIPro::wrongkeys="Warning: Key(s) `1` not known.";
CIPro::dataformat="Data not a list of associations.";
CIPro::nametaken="Name for data set already taken.";
CIPro::datamissing="Data set `1` does not exist.";
CIPro::badass="Association(s) not well-formed.";
CIPro::noass="Input is not an association or a list of associations.";
CIPro::wrongdims="Dimensions are incompatible.";
CIPro::noconf="Association must contain key `1`.";
CIPro::depmissing="Warning: Dependencies `1` are missing for property `2`.";
CIPro::"map error"="`1` is not consistent with spaces.";
CIPro::notavailable="`1` is not available.";


(* ::Section::Closed:: *)
(*Initialise package*)


(* ::Subsection::Closed:: *)
(*Print package header*)


Begin["`Private`"]
Print[Style["CIPro 1.0", "Title", TextAlignment -> Center, RGBColor[.75,.25,.05]]];
Print[Style["Complete Intersections in Products of Projective Spaces",RGBColor[.75,.25,.05],TextAlignment -> Center, "Section"]];
Print[Style["Andre Lukas, James Gray, Lara Anderson, Andrei Constantin, Yang-Hui He, Seung-Joo Lee",FontColor -> Black,TextAlignment -> Center,"Subsection",FontSize -> 14]];
Print[Style[Import[$UserBaseDirectory<>"/Applications/CIProAux/Cinnamon.png"], TextAlignment->Center,Magnification->0.75]];

Print[Style["Execute \!\(\*
StyleBox[\"CIPro\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"[\",\nFontWeight->\"Bold\"]\)\!\(\*
StyleBox[\"]\",\nFontWeight->\"Bold\"]\) for help",FontColor -> Black,TextAlignment -> Center, FontSize -> 14,FontFamily->"Times"]];


(* ::Subsection::Closed:: *)
(*Global package options*)


Options[CIPro]:={"DataPath"->$UserBaseDirectory<>"/Applications/CIProData/",
                 "ExamplePath"->$UserBaseDirectory<>"/Applications/CIProExamples/",
                 "ManualPath"->$UserBaseDirectory<>"/Applications/CIProExamples/manual/",
                  "KFormsName"->Global`J,"KModuliName"->Global`t,"CoordName"->Global`x,
                  "MaxGenOrder"->99,"GroupElement"->Global`g};


(* ::Subsection::Closed:: *)
(*Data and packages*)


(* initialise associations for data and data info *)
CIPro`CIData=<||>;
CIPro`DataInfo=Get[("DataPath"/.Options[CIPro])<>"DataInfo.txt"];

(* load Albrecht Klemm's package for (genus 1) GV invariants *)
Get[$UserBaseDirectory<>"/Applications/CIProAux/inst3.m"];
Quiet[<<Combinatorica`];

(* load mathematical help files *)
CIPro`MathInfo=Import[("ExamplePath"/.Options[CIPro])<>"manual/keyinfo.pdf",ImageResolution->300];
CIPro`MathInfoText=Import[("ExamplePath"/.Options[CIPro])<>"manual/keyinfo.pdf","PagePlaintext",ImageResolution->300];
CIPro`MathGeneralInfo=Import[("ExamplePath"/.Options[CIPro])<>"manual/generalinfo.pdf",ImageResolution->300];
CIPro`CIProManual=Import[("ExamplePath"/.Options[CIPro])<>"manual/CIPro_Manual.pdf",ImageResolution->300];


(* ::Subsection::Closed:: *)
(*Dependencies set-up for CIProp*)


CIPro`Private`CIProMod=<||>; CIPro`Private`CIProDep=<||>; CIPro`Private`CIProInfo=<||>; 
CIPro`Private`CIProSection=<|"CIs"->{},"Symmetries"->{},"CIs & Symmetries"->{},"CIs & LineSums"->{}|>;
Options[CIPro`CIProp]:={"Format"->"Full","CoeffRange"->{1,100},"CoeffType"->"Integer","MaxDeg"->5,
                        "FieldChar"->101,"HilbertFormat"->{},"CohQ"->0,"Modulus"->0,"CohQ"->0,"CohInfo"->{},
                        "Eqs"->None};


(* ::Subsection::Closed:: *)
(*Dependencies set-up for CIMod*)


CIPro`Private`CIModMod=<||>; CIPro`Private`CIModDep=<||>; CIPro`Private`CIModInfo=<||>; 
CIPro`Private`CIModSection=<|"CIs"->{},"Symmetries"->{},"CIs & Symmetries"->{},"CIs & LineSums"->{}|>;
Options[CIPro`CIMod]:={"Format"->"Full","TensorPower"->2,"Map"->Automatic,"Space"->"Ker","Modulus"->0,
                       "Method"->Automatic,"Ekpq"->{0,0,0},"CohProt"->False,"CohFormat"->"Dim","CohSum"->True,
                       "CoeffRange"->{1,100},"CoeffType"->"Integer"};


(* ::Section::Closed:: *)
(*System and auxiliary modules*)


(* ::Subsection::Closed:: *)
(*Overview help for auxiliary modules*)


CIPro`CISystemModules::usage="A list of package auxiliary modules (see ?modulename for more details):\n"<>
"\[FilledSmallSquare] MM: converts matrices contained in expressions into matrixform.\n"<>
"\[FilledSmallSquare] CharConvert: converts characteristic classes from sybolic into numerical form.\n"<>
"\[FilledSmallSquare] C2OtherClass: converts a Chern class into another class, e.g. Todd class.\n"<>
"\[FilledSmallSquare] MatProjEquiv: tests if two matrices are multi-projectively equivalent.\n"<>
"\[FilledSmallSquare] BlockMatrix2: forms a block matrix from two matrices.\n"<>
"\[FilledSmallSquare] BlockMatrix: forms a block matrix from a list of matrices.\n"<>
"\[FilledSmallSquare] PermMatrix: extracts a permutation matix associated to a matrix.\n"<>
"\[FilledSmallSquare] TransformPoly: transform a polynomial by a matrix acting on coordinates.\n"<>
"\[FilledSmallSquare] ReynoldsPoly: act with the Reynolds operator of a given matrix group on a polynomials.";


(* ::Subsection::Closed:: *)
(*Basic utilities*)


(* ::Subsubsection::Closed:: *)
(*MM: display matrices in expressions in matrix form*)


CIPro`MM::usage="MM[expr], converts matrices contained in expr into matrix form.";

MM[expr_]:=Module[{X},
 ReplaceAll[expr,X_/;MatrixQ[X]->MatrixForm[X,TableDepth->2]]]; 


(* ::Subsubsection::Closed:: *)
(*StPrint: print text in a uniform style*)


CIPro`StPrint::usage="StPrint[txt,<color>], to print txt in a nice style.";

StPrint[txt_,color_:Darker[Gray]]:=Print[Style[txt,FontColor -> color,TextAlignment -> Left, FontSize -> 16,FontFamily->"Times"]];


(* ::Subsubsection::Closed:: *)
(*InfoPrint: print information text in a box*)


CIPro`InfoPrint::usage="StPrint[txt], to print information text in a box.";

InfoPrint[txt_]:=Print[Framed[Style[txt,Black,TextAlignment -> Left, "Text",FontFamily->"Times"],ImageSize->Automatic,FrameStyle->Black,Background->RGBColor[0.96,0.99,1]]]


(* ::Subsubsection::Closed:: *)
(*ErrorPrint: print an error message*)


CIPro`ErrorPrint::usage="ErrorPrint[tes], to print an error in a standard format.";

ErrorPrint[txt_]:=Print[Style["CIPro error: ",Black,FontColor->RGBColor[0.88,0.08,0.23],TextAlignment -> Left, FontSize -> 11,FontFamily->"Times"],Style[txt,FontColor->Gray,TextAlignment -> Left, FontSize -> 12,FontFamily->"Times"]]


(* ::Subsubsection::Closed:: *)
(*WarningPrint: print a warning message*)


CIPro`WarningPrint::usage="WarningPrint[tes], to print a warning in a standard format.";

WarningPrint[txt_]:=Print[Style["CIPro warning: ",Black,FontColor->RGBColor[0.88,0.08,0.23],TextAlignment -> Left, FontSize -> 11,FontFamily->"Times"],Style[txt,FontColor->Gray,TextAlignment -> Left, FontSize -> 12,FontFamily->"Times"]]


(* ::Subsubsection::Closed:: *)
(*HelpPrint: print out help *)


CIPro`HelpPrint::usage="HelpPrint[key,scope], to print out information about a keyword.";

HelpPrint[key_,scope_:{}]:=Module[{helpfn,pdf,exfn,info,clst,i,pos},
If[KeyExistsQ[CIPro`Private`CIProInfo,key],info=CIPro`Private`CIProInfo[key]];
If[KeyExistsQ[CIPro`Private`CIModInfo,key],info=CIPro`Private`CIModInfo[key]];
If[scope==={} || scope==="",
  (* short printout *)
  InfoPrint["Info on "<>key<>": "<>info],
  (* long printout *)
  InfoPrint["Info on "<>key<>": "<>info<>" Mathematical background and example:"];
  clst={};
  For[i=1,i<=Length[CIPro`MathInfoText],i++,
    pos=Map[First,StringPosition[CIPro`MathInfoText[[i]],key<>":"]];
    If[MemberQ[pos,1],clst=Append[clst,i]];
  ];
  If[Length[clst]>0,
    For[i=1,i<=Length[clst],i++,
      Print[Framed[CIPro`MathInfo[[clst[[i]]]],ImageSize->900,Background->RGBColor[0.96,0.99,1]]]], 
  Message[CIPro::notavailable,"Mathematical background for "<>key]
 ];
 exfn=("ExamplePath"/.Options[CIPro])<>"SmallExamples/"<>key<>".nb"; 
 If[FileExistsQ[exfn],CellPrint[First[Get[exfn]]],
 Message[CIPro::notavailable,"Example for "<>key]]; 
];
];


(* ::Subsubsection::Closed:: *)
(*CIPro: basic help in command style*)


CIPro[str_:""]:=Module[{doc},

InfoPrint[CIPro::usage];
If[str=!="",
  doc=Switch[str,
    "Long",CIPro`MathGeneralInfo,
    "Manual",CIPro`CIProManual,
     _,CIPro`MathGeneralInfo];
  For[i=1,i<=Length[doc],i++,
        Print[Framed[doc[[i]],ImageSize->900,Background->RGBColor[0.96,0.99,1]]]];
];        
];


(* ::Subsection::Closed:: *)
(*Characteristic classes*)


(* ::Subsubsection::Closed:: *)
(*ClassConvert: convert characteristic class into numerical form*)


CIPro`ClassConvert::usage="ClassConvert[c,isec,cidim,pic], where c is the characteristic class, as a polynomial in the basis forms for \!\(\*SuperscriptBox[\(H\), \(2\)]\)(name set in global option \"KFormsName\"), isec are the intersection numbers, cidim is the complex dimension of the space and h11 is the Hodge number \!\(\*SuperscriptBox[\(h\), \(1, 1\)]\).\n"<>
"\[FilledSmallSquare] The characteristic class c is converted into numerical form, relative to the basis, where higher classes are dualised using the intersection numbers."; 

(* auxiliary: convert symbolic characteristic class into numerical form *)
ClassConvert[csym_,isec_,cidim_,h11_]:=Module[
{cnum,i1,i,ci,ind,j,cic,c,Jname,Js,p,d,csym1},

(* options *)
Jname="KFormsName"/.Options[CIPro];
Js=Table[Subscript[Jname, i],{i,1,h11}];

(* numerical version of Chern classes *)
csym1=csym+Sum[d*First[Js]^p,{p,1,cidim}];
cnum=Rest[Normal[CoefficientArrays[csym1,Js]]]/.d->0;

(* convert higher Chern classes using intersection numbers *)
i1=Floor[cidim/2]; c=Take[cnum,{1,i1}];
For[i=i1+1,i<=cidim,i++,
  ci=cnum[[i]]; ind=Table[{j,j+i-1},{j,cidim-i+1,cidim-1}];
  cic=TensorContract[isec . ci,ind];
  c=Append[c,cic];
];  

c];


(* ::Subsubsection::Closed:: *)
(*Class2Class: convert one type of characteristic class into another*)


CIPro`Class2Class::usage="Class2Class[class,cidim,h11,rk,type,newtype], where class is the characteristic class, as a polynomial in the h11 basis forms, cidim is the complex dimension of the space, rk is the rank of the underlying bundle, type is the class type of class (default \"C\") and newtype is the class type to be converted to (default \"Ch\").\n"<>
"\[FilledSmallSquare] Output is class of the given type converted into the class of newtype.\n"<>
"\[FilledSmallSquare] Currently implemented:\"C\"->\"Ch\", \"C\"->\"Td\", \"Ch\"->\"C\".";

Class2Class[class_,cidim_,h11_,rk_,old_:"C",new_:"Ch"]:=Module[{Js,repl,c,i,x,p,newclass,Jname},

(* basic definitions *)
Jname="KFormsName"/.Options[CIPro];
Js=Table[Subscript[Jname, i],{i,1,h11}];
repl=Table[Js[[i]]->x*Js[[i]],{i,1,Length[Js]}];
c=PadRight[Coefficient[class/.repl,Table[x^p,{p,1,cidim}]],5];

newclass=Switch[{old,new},
  {"C","Ch"},{rk,c[[1]],c[[1]]^2/2-c[[2]],c[[1]]^3/6-c[[1]]c[[2]]/2+c[[3]]/2},
               (c[[1]]^4-4c[[1]]^2c[[2]]+2c[[2]]^2+4c[[1]]c[[3]]-4c[[4]])/24,
               (c[[1]]^5-5c[[1]]^3c[[2]]+5c[[1]]^2c[[3]]-5c[[1]]c[[4]]-5c[[2]]c[[3]]+5c[[1]]c[[2]]^2+5c[[5]])/120,
  {"C","Td"},{1,c[[1]]/2,(c[[1]]^2+c[[2]])/12,c[[1]]c[[2]]/24,(-c[[1]]^4+4c[[1]]^2c[[2]]+c[[1]]c[[3]]+3c[[2]]^2-c[[4]])/720,
        (-c[[1]]^3c[[2]]+c[[1]]^2c[[3]]-c[[1]]c[[4]]+3c[[1]]c[[2]]^2)/1440},
  {"Ch","C"},{1,c[[1]],1/2 (c[[1]]^2-2 c[[2]]),1/6 (c[[1]]^3-6 c[[1]] c[[2]]+12 c[[3]]),
              1/24 (c[[1]]^4-12 c[[1]]^2 c[[2]]+12 c[[2]]^2+48 c[[1]] c[[3]]-144 c[[4]]),
              1/120 (c[[1]]^5-20 c[[1]]^3 c[[2]]+60 c[[1]] c[[2]]^2+120 c[[1]]^2 c[[3]]-240 c[[2]] c[[3]]-720 c[[1]] c[[4]]+2880 c[[5]])},      
  _,class
];

Total[Take[newclass,Min[cidim+1,5]]]//Expand];


(* ::Subsection::Closed:: *)
(*Some modules for matrices*)


(* ::Subsubsection::Closed:: *)
(*MatProjEquiv: tests if two matrices are projectively equivalent*)


CIPro`MatProjEquiv::usage="MatProjEquiv[m1,m2,dPs], tests if m1.Inverse[m2] is diagonal and, if so, if this diagonal matrix has the structure of projective identifications on a product of projective spaces with dimensions listed in dPs.\n"<>
"\[FilledSmallSquare] Output is True or False.";

MatProjEquiv[m1_/;MatrixQ[m1],m2_/;MatrixQ[m2],dPs_List]:=Module[{dim,m,d,dm,equiv,k,r,dp},

(* basic set-up *)
dim=Join[Dimensions[m1],Dimensions[m2]]//DeleteDuplicates;
If[Length[dim]>1 || First[dim]!=Total[dPs],Message[CIPro::wrongdims];Return[False]];
dim=First[dim];
If[MatrixRank[m1]!=dim || MatrixRank[m2]!=dim,Return[False]];

(* test if two matrices differ by a diagonal matrix *)
m=m1 . Inverse[m2]; d=Diagonal[m]; dm=m-DiagonalMatrix[d];
If[Total[Abs[Flatten[dm]]]>10^(-10),Return[False]];

(* test if diagonal matrix is of the right form *)
equiv=True; k=1; r=1;
While[equiv && k<=Length[dPs],
  dp=Take[d,{r,r+dPs[[k]]-1}];
  If[Total[Abs[dp-First[dp]]]>10^(-10),equiv=False];
  r=r+dPs[[k]]; k++;
];  

equiv];


(* ::Subsubsection::Closed:: *)
(*MatProjTrivial: tests if a matrix is projectively trivial*)


CIPro`MatProjTrivial::usage="MatProjTrivial[mat,dPs], tests if the matrix mat is (multi-) projectively trivial. The list dPs specifies the dimensions of the projective factors.\n"<>
"\[FilledSmallSquare] Output is True or False.";

MatProjTrivial[mat_/;MatrixQ[mat],dPs_List]:=Module[{d,diag,llst},

d=Total[dPs];
If[Dimensions[mat]!={d,d} || !DiagonalMatrixQ[mat],Return[False]];
diag=Map[DeleteDuplicates,TakeList[Diagonal[mat],dPs]];
llst=Map[Length,diag];
If[llst==Table[1,{Length[dPs]}],Return[True],Return[False]];
];


(* ::Subsubsection::Closed:: *)
(*BlockMatrix2: construct a block-diagonal matrix from two individual blocks*)


CIPro`BlockMatrix2::usage="BlockMatrix2[mat1,mat2], where mat1 and mat2 are matrices.\n"<>
"\[FilledSmallSquare] Output is block-diagonal matrix with mat1 and mat2 along the diagonal.";

BlockMatrix2[mat1_/;MatrixQ[mat1],mat2_/;MatrixQ[mat2]]:=Module[{dim1,dim2,dim,mat1pad,mat2pad},

dim1=Dimensions[mat1]; dim2=Dimensions[mat2]; dim=dim1+dim2;
mat1pad=Map[PadRight[#,dim[[2]]]&,mat1];
mat2pad=Map[PadLeft[#,dim[[2]]]&,mat2];

Join[mat1pad,mat2pad]];


(* ::Subsubsection::Closed:: *)
(*BlockMatrix: constructs a block-diagonal matrix from individual blocks*)


CIPro`BlockMatrix::usage="BlockMatrix[matlst], where matlst is a list of matrices.\n"<>
"\[FilledSmallSquare] Output is block-diagonal matrix with the matrices in matlst along the diagonal.";

BlockMatrix[matlst_/;ListQ[matlst]]:=Module[{mlst,mat,i},

(* select matrices and determine their sizes *)
mlst=Select[matlst,MatrixQ[#]&];
If[Length[mlst]==0,Return[None]];
mat=First[mlst];
For[i=2,i<=Length[matlst],i++,
  mat=BlockMatrix2[mat,matlst[[i]]]
];

mat];


(* ::Subsubsection::Closed:: *)
(*PermMatrix: construct a permutation matrix associated to a matrix*)


CIPro`PermMatrix::usage="PermMatrix[mat,dimlst], where mat is a matrices and dimlst a list of dimensions.\n"<>
"\[FilledSmallSquare] Output is permutation matrix extracted from mat, by splitting the matrix into blocks given in dimlst, replacing a non-zero block by 1 and a zero block by 0.";

PermMatrix[mat_/;MatrixQ[mat],dimlst_/;ListQ[dimlst]]:=Module[
  {dim,pdim,perm,i,j,i1,j1,di,dj,matij},

dim=Total[dimlst];
If[Dimensions[mat]!={dim,dim},Message[CIPro::wrongdims]; Return[<|"Gen"->{}|>]];
pdim=Length[dimlst];

perm=Table[0,{pdim},{pdim}];
For[i=1,i<=pdim,i++,
  i1=Total[Take[dimlst,i-1]]+1; di=dimlst[[i]]-1;
  For[j=1,j<=pdim,j++,
    j1=Total[Take[dimlst,j-1]]+1; dj=dimlst[[j]]-1;
    matij=Map[Take[#,{j1,j1+dj}]&,Take[mat,{i1,i1+di}]];
    If[Total[Abs[Flatten[matij]]]>0,perm[[i,j]]=1];
  ];  
];

perm];


(* ::Subsubsection::Closed:: *)
(*SymmMatNormal: normal form of symmetric matrix under conjugation with permutations*)


CIPro`SymmMatNormal::usage="SymmMatNormal[m], where m is a symmetric matrix.\n"<>
"\[FilledSmallSquare] Finds a normal of of m under conjugation P.m.Transpose[P], where P is permutation matrix.\n"<>
"\[FilledSmallSquare] Output is a pair {mnorm,P}, where mnorm is the normal form of m and P the permutation matrix which generates it.";

SymmMatNormal[mat_/;(MatrixQ[mat,NumberQ]&& SymmetricMatrixQ[mat]),opt___]:=Module[
{d,rowtally,rowtally1,p,A,dlst,i,r0,r1,Apart,Asort,Ppart,plst,Plst,Alst,Amax},

(* options and basic definitions *)
d=Length[mat];
(* tally rows and group rows with same tally *)
rowtally=Map[Sort[Tally[#]]&,mat];
rowtally1=Sort[rowtally];
p=System`Permute[IdentityMatrix[d],FindPermutation[rowtally,rowtally1]];
A=p . mat . Transpose[p];
dlst=Map[Length,Split[rowtally1]];

(* extract partial matrices and bring them into normal form *)
plst={};
For[i=1,i<=Length[dlst],i++,
 r0=Total[Take[dlst,i-1]]+1; r1=r0+dlst[[i]]-1;
 Apart=Transpose[Take[Transpose[Take[A,{r0,r1}]],{r0,r1}]];
 {Asort,Ppart}=CIPro`SymmMatNormal0[Apart];
 plst=Append[plst,Ppart];
];
(* form block permutation matrix from partial permutations *)
Plst=Map[BlockMatrix,Tuples[plst]];

Alst=Map[{# . A . Transpose[#],#}&,Plst];
Amax=MaximalBy[Alst,Flatten[First[#]]&]//First;

{First[Amax],Last[Amax] . p}];

(* auxiliary module *)

CIPro`SymmMatNormal0::usage="SymmMatNormal0[m], finds a normal form of a symmetric matrix m under conjugation P.m.Transpose[P], where P is a permutation matrix.";

Options[SymmMatNormal0]:={"MaxDim"->8};

SymmMatNormal0[mat_/;MatrixQ[mat,NumberQ],opt___]:=Module[
{d,plst,clst,maxdim,cmax,pinv},

(* options *)
maxdim="MaxDim"/.{opt}/.Options[SymmMatNormal0];
d=Length[mat];
If[d>maxdim,ErrorPrint["Warning: Dimension to large - may take some time."]];
(* act with list of permutations *)
plst=Permutations[IdentityMatrix[d]];
clst=Map[{# . mat . Transpose[#],#}&,plst];
(* choose maximal version of matrix *)
cmax=MaximalBy[clst,Flatten[First[#]]&]//First;

pinv=Map[Last,Select[clst,First[#]==First[cmax]&]];

{First[cmax],pinv}];


(* ::Subsubsection::Closed:: *)
(*MatNormal: normal form a a matrix under row and column permutations*)


CIPro`MatNormal::usage="MatNormal[m], where m is a matrix finds a normal form of m under row and column permutations.\n"<>
"\[FilledSmallSquare] Output is a triple {mnorm,P,Q}, where mnorm is the normal form of m and P,Q are permutation matrices with mnorm=P.m.Transpose[Q].";

MatNormal[mat_/;MatrixQ[mat,NumberQ]]:=Module[{d,A,Asort,P,mrow,mnorm,Q},

d=Dimensions[mat];A=mat . Transpose[mat];
{Asort,P}=SymmMatNormal[A];
mrow=Transpose[P . mat];
mnorm=ReverseSort[mrow];
Q=System`Permute[IdentityMatrix[d[[2]]],FindPermutation[mrow,mnorm]];

{Transpose[mnorm],P,Q}];


(* ::Subsection::Closed:: *)
(*Some symmetry modules*)


(* ::Subsubsection::Closed:: *)
(*TransformPoly:  transform a polynomial by a matrix acting on coordintes*)


CIPro`TransformPoly::usage="TransformPoly[p,coords,g], where p is the polynomial, coords is  the list of coordinates and g a matrix that acts on the coordinates.\n"<>
"\[FilledSmallSquare] Output is the polynomial transformed with g.";

TransformPoly[p_,coords_/;ListQ[coords],g_/;MatrixQ[g]]:=Module[{c,dim,ctrans,d,i,dummy,repl,repl1},

c=Flatten[coords]; dim=Length[c];
dummy=Table[d[i],{i,1,dim}];
If[Dimensions[g]!={dim,dim}, Message[CIPro::wrongdims];Return[$Failed]];
repl=Thread[Rule[c,g . dummy]]; repl1=Thread[Rule[dummy,c]];

p/.repl/.repl1];


(* ::Subsubsection::Closed:: *)
(*ReynoldsPoly: apply Reynolds operator to polynomial list*)


CIPro`ReynoldsPoly::usage="ReynoldsPoly[plst,coords,group], where plst is a list of polynomials, coords is the list of coordinates and group a list of matrices acting on the coordinates and the polynomial vector.\n"<>
"\[FilledSmallSquare] Specifically, the first entry of every group element acts on the coordinates, the second on the polynoial vector (trivial action assumed if second entry is missing).\n"<>
"\[FilledSmallSquare] Output is a list of polynomials forming a group singlet.";

ReynoldsPoly[plst_/;ListQ[plst],coords_/;ListQ[coords],group_/;ListQ[group]]:=Module[
  {invplst,i,K,g2,gprod,g,gplst},

(* generate invariant *)
K=Length[plst];
invplst=Table[0,{K}];
For[i=1,i<=Length[group],i++,
  gprod=group[[i]]; g=gprod[[1]];
  gplst=Map[TransformPoly[#,coords,g]&,plst];
  If[Length[gprod]>1,g2=Last[gprod];
    If[Dimensions[g2]=={K,K},gplst=g2 . gplst]
  ];
  invplst=invplst+gplst;  
];    
  
Expand[invplst/Length[group]]//Simplify];


(* ::Subsection::Closed:: *)
(*Some modules for polynomials*)


(* ::Subsubsection::Closed:: *)
(*MList: produce list of monomials of a given degree in specified list of variables*)


CIPro`MList::usage="MList[deg,var], produce lists of monomials with given degree in specified variables.";

MList[deg_Integer, var_List] := Module[{powers},

If[deg<0,Return[{0}]];
If[var=={},Return[{}]];

powers=DeleteDuplicates[Flatten[Map[Permutations,Map[PadRight[#,Length[var]]&,IntegerPartitions[deg]]],1]];

Map[Apply[Times, #] &, Map[Power[var, #] &, powers]]];


(* ::Subsubsection::Closed:: *)
(*MMList: produce monomials of a given multi-degree in specified list of variable lists*)


CIPro`MMList::usage="MMList[multideg,var], produce lists of monomials with given multi-degree in specified list of variable lists.";

MMList[mdeg_/;VectorQ[mdeg,IntegerQ],var_List]:=Module[{i,monlst},

If[var==={},Return[{}]];

monlst=Map[Apply[Times,#]&,Tuples[Table[MList[mdeg[[i]],var[[i]]],{i,1,Length[mdeg]}]]];

monlst];


(* ::Subsubsection::Closed:: *)
(*RandomPoly: generate a random polynomial of a given multi-degree*)


CIPro`RandomPoly::usage="RandomPoly[multideg,var,opt], generate a random polynomial of a given multi-degree.";

Options[RandomPoly]:={"CoeffRange"->{1,100},"CoeffType"->"Integer"};

RandomPoly[mdeg_/;VectorQ[mdeg,IntegerQ],var_List,opt___]:=Module[{monlst,len,clst,coefftype,coeffrange},

(* options *)
coefftype="CoeffType"/.{opt}/.Options[RandomPoly]; 
coeffrange="CoeffRange"/.{opt}/.Options[RandomPoly];

(* monomials *)
monlst=MMList[mdeg,var]; len=Length[monlst];

(* coefficients *)
clst=Switch[coefftype,
  "Integer",RandomInteger[coeffrange,len],
  "Real",RandomReal[coeffrange,len],
  "CInteger",RandomInteger[coeffrange,len]+I RandomInteger[coeffrange,len],
  "CReal",RandomReal[coeffrange,len]+I RandomReal[coeffrange,len],
  _,Table[Subscript[coefftype, i],{i,1,len}]
];

clst . monlst];


(* ::Subsection::Closed:: *)
(*Some modules for line bundle sums*)


(* ::Subsubsection::Closed:: *)
(*  LineTensor: tensor product of two sums of line bundles*)


CIPro`LineTensor::usage="* usage : 'LineTensor[line1,line2]', where 'line1' and 'line2' are two sums of line bundles (see '?SumofLineBundles').\n"<>
" * output  : The tensor product of 'line1' and 'line2' as a sum of line bundles.";

LineTensor[line1_List,line2_List]:=Transpose[Flatten[Outer[Plus,Transpose[line1],Transpose[line2],1],1]];


(* ::Subsubsection::Closed:: *)
(*  LineWedge: wedge product of two sums of line bundles*)


CIPro`LineWedge::usage="* usage : 'LineWedge[line,p]', where 'line' is a sum of line bundles (see '?SumofLineBundles') U and 'p' is an integer >=0.\n"<>
" * output  : The pth wedge power \!\(\*SuperscriptBox[\"\[CapitalLambda]\", \"p\"]\)U of the sum of line bundles.";

LineWedge[line_List,p_Integer/;p>=0]:=Module[{lineT,nP,numline},

nP=Length[line];
lineT=Transpose[line];
numline=Length[lineT];
If[p==0 || p>numline,Return[Table[{0},{nP}]],
   Return[Transpose[Apply[Plus,Subsets[lineT,{p}],1]]]]];


(* ::Subsubsection::Closed:: *)
(*  LineSymm: wedge product of two sums of line bundles*)


CIPro`LineSymm::usage="* usage : 'LineSymm[line,p]', where 'line' is a sum of line bundles (see '?SumofLineBundles') U and 'p' is an integer >=0.\n"<>
" * output  : The pth symmetric power \!\(\*SuperscriptBox[\"S\", \"p\"]\)U of the sum of line bundles.";

LineSymm[line_List,p_Integer/;p>=0]:=Module[{i,nP,lineT,dline,numline,lst},

nP=Length[line];
lineT=Transpose[line];
If[p==0,Return[Table[{0},{nP}]],
 lineT=Transpose[line];
 numline=Length[lineT];
 lst=DeleteDuplicates[Map[Sort,Tuples[Table[{i},{i,1,numline}],p]]];
 Return[Transpose[Apply[Plus,Map[Extract[lineT,#]&,lst],1]]]]]; 


(* ::Section::Closed:: *)
(*Modules for CI properties*)


(* ::Subsection::Closed:: *)
(*Basic modules*)


(* ::Subsubsection::Closed:: *)
(*DefConf: define default configuration*)


CIPro`DefConf::usage="DefConf[ass,opt], creates a default configuration matrix.";

AssociateTo[CIPro`Private`CIProMod,"Conf"->DefConf]; AssociateTo[CIPro`Private`CIProDep,"Conf"->{}];
AssociateTo[CIPro`Private`CIProInfo,"Conf"->"Configuration matrix for a CI, with each column a multi-degree of one of the defining polynomials."];
AppendTo[CIPro`Private`CIProSection["CIs"],"Conf"];

DefConf[ass_,opt___]:=Module[{},

If[KeyExistsQ[ass,"DimPs"],Table[{},{Length[ass["DimPs"]]}]]];


(* ::Subsubsection::Closed:: *)
(*DimPsCY: compute dimension of projective factors*)


CIPro`DimPs::usage="DimPs[ass,opt], creates dimension list of projective factors (default is CY).";

AssociateTo[CIPro`Private`CIProMod,"DimPs"->DimPs]; AssociateTo[CIPro`Private`CIProDep,"DimPs"->{"Conf"}];
AssociateTo[CIPro`Private`CIProInfo,"DimPs"->"Dimensions of projective ambient space factors."];
AppendTo[CIPro`Private`CIProSection["CIs"],"DimPs"];

DimPs[ass_,opt___]:=Map[Max[Total[#],2]&,ass["Conf"]]-1;


(* ::Subsubsection::Closed:: *)
(*AmbCoords: generate ambient coordinates*)


CIPro`AmbCoords::usage="AmbCoords[ass,opt], creates a list of projective ambient space coordinates.";

AssociateTo[CIPro`Private`CIProMod,"AmbCoords"->AmbCoords]; AssociateTo[CIPro`Private`CIProDep,"AmbCoords"->{"Conf","DimPs"}];
AssociateTo[CIPro`Private`CIProInfo,"AmbCoords"->"A list of lists, each one containing the homogeneous coordinates of one of the ambient space projective factors."];
AppendTo[CIPro`Private`CIProSection["CIs"],"AmbCoords"];

AmbCoords[ass_,opt___]:=Module[{cname,dPs,i,j},

cname="CoordName"/.{opt}/.Options[CIPro]; dPs=ass["DimPs"];

If[!Apply[And,Map[IntegerQ,Flatten[dPs]]],ErrorPrint["Ambient space data must all be given in terms of integers to compute this keyword."];Return[$Failed];
];

If[ListQ[cname],
 If[Length[cname]>=Length[dPs],Return[Table[Table[Subscript[(cname[[i]]), j],{j,0,dPs[[i]]}],{i,1,Length[dPs]}]]],
   Return[Table[Table[Subscript[cname, i,j],{j,0,dPs[[i]]}],{i,1,Length[dPs]}]]]];


(* ::Subsubsection::Closed:: *)
(*AmbDim: compute ambient space dimension*)


CIPro`AmbDim::usage="AmbDim[ass,opt], computes the dimension of the ambient space.";

AssociateTo[CIPro`Private`CIProMod,"AmbDim"->AmbDim]; AssociateTo[CIPro`Private`CIProDep,"AmbDim"->{"Conf","DimPs"}];
AssociateTo[CIPro`Private`CIProInfo,"AmbDim"->"The dimension of the ambient space for CIs."];
AppendTo[CIPro`Private`CIProSection["CIs"],"AmbDim"];

AmbDim[ass_,opt___]:=Total[ass["DimPs"]];


(* ::Subsubsection::Closed:: *)
(*CIDim: compute dimension of CI*)


CIPro`CIDim::usage="CIDim[ass,opt], computes the dimension of the CI.";

AssociateTo[CIPro`Private`CIProMod,"CIDim"->CIDim]; AssociateTo[CIPro`Private`CIProDep,"CIDim"->{"Conf","DimPs","AmbDim"}];
AssociateTo[CIPro`Private`CIProInfo,"CIDim"->"The dimension of the CI."];
AppendTo[CIPro`Private`CIProSection["CIs"],"CIDim"];

CIDim[ass_,opt___]:=Module[{conf,nzeros,confT,nneg},
conf=ass["Conf"]; confT=Transpose[conf];
nzeros=Count[Map[Total,Abs[confT]],0];
If[nzeros>0,WarningPrint["Configuarion matrix contains zero degree section."]; Return[-1]];
nneg=Count[Map[Apply[Or,#]&,Negative[confT]],True];
If[nneg>0,WarningPrint["Configuraion contains "<>ToString[nneg]<>" section(s) with negative degrees."]];

ass["AmbDim"]-Dimensions[conf][[2]]+nneg];


(* ::Subsubsection::Closed:: *)
(*CYQ: check if CI is a CY*)


CIPro`CYQ::usage="CYQ[ass,opt], check if CI is a CY.";

AssociateTo[CIPro`Private`CIProMod,"CY"->CYQ]; AssociateTo[CIPro`Private`CIProDep,"CY"->{"Conf","DimPs"}];
AssociateTo[CIPro`Private`CIProInfo,"CY"->"Is the CI a CY?"];
AppendTo[CIPro`Private`CIProSection["CIs"],"CY"];

CYQ[ass_,opt___]:=Reduce[(Map[Total,ass["Conf"]]-1)==ass["DimPs"]];


(* ::Subsubsection::Closed:: *)
(*CINormal: bring CI configuration into normal form*)


CIPro`CINormal::usage="CINormal[ass,opt], brings a CI configuration matrix into normal form.";

AssociateTo[CIPro`Private`CIModMod,"CINormal"->CINormal]; AssociateTo[CIPro`Private`CIModDep,"CINormal"->{"Conf","DimPs"}];
AssociateTo[CIPro`Private`CIModInfo,"CINormal"->"Produce an equivalent CI with configuration matrix broght into a normal form."];
AppendTo[CIPro`Private`CIModSection["CIs"],"CINormal"];

CINormal[ass_,opt___]:=Module[{ass1,conf,dimPs,confnorm,P,Q,dimPsnew},

(* definitions *)
If[AssociationQ[ass],ass1=ass,ass1=First[ass]];
conf=ass1["Conf"]; dimPs=ass1["DimPs"];
If[!Apply[And,Map[IntegerQ,Flatten[{conf,dimPs}]]],ErrorPrint["CI data must all be given in terms of integers to compute this keyword."];Return[$Failed];
];

{confnorm,P,Q}=MatNormal[conf];
dimPsnew=P . dimPs;

<|"Conf"->confnorm,"DimPs"->dimPsnew,"RowPerm"->P,"ColPerm"->Q|>];


(* ::Subsubsection::Closed:: *)
(*CIEquiv: check if two CIs are equivalent*)


CIPro`CIEquiv::usage="CYQ[ass,opt], checks if two CIs have equivalent configuration matrices, due to row and column permutations.";

AssociateTo[CIPro`Private`CIModMod,"CIEquiv"->CIEquiv]; AssociateTo[CIPro`Private`CIModDep,"CIEquiv"->{"Conf","DimPs"}];
AssociateTo[CIPro`Private`CIModInfo,"CIEquiv"->"Check if two CIs are equivalent. The output is True or False."];
AppendTo[CIPro`Private`CIModSection["CIs"],"CIEquiv"];

CIEquiv[ass_,opt___]:=Module[{ass1,ass2,equiv},

ass1=CINormal[{ass[[1]]}]; ass2=CINormal[{ass[[2]]}];
If[ass1["Conf"]==ass2["Conf"] && ass1["DimPs"]==ass2["DimPs"],equiv=True,equiv=False];

equiv];


(* ::Subsubsection::Closed:: *)
(*CIEquiv2: check if two CIs are equivalent*)


CIPro`CIEquiv2::usage="CINormal[ass1,ass2,pow,opt], compares two configuration matrices and decides whether they are related by permutations. pow is a method related integer: try3.";


CIEquiv2[ass1_,ass2_,pow_]:=Module[{c1,c2,tc1,tc2,powerrowsums1,powerrowsums2,powercolsums1,powercolsums2,rowtest,coltest,rowpermssametest,colpermssametest,rowperm,colperm,rowmatrix,colmatrix,rowsumssametest,colsumssametest,check},
c1=ass1["Conf"];
c2=ass2["Conf"];

(*Deal with rows first. Compute sums of powers of entries in the rows and then ask what permutations make them the same*)

powerrowsums1=Table[Table[Total[c1[[i]]^j],{i,1,Length[c1]}],{j,1,pow}];
powerrowsums2=Table[Table[Total[c2[[i]]^j],{i,1,Length[c2]}],{j,1,pow}];
rowsumssametest=Sort[Table[Sort[powerrowsums1[[i]]],{i,1,Length[powerrowsums1]}]]==Sort[Table[Sort[powerrowsums2[[i]]],{i,1,Length[powerrowsums2]}]];
If[!rowsumssametest,Return[{False,{}}]];

rowtest=DeleteDuplicates[Table[FindPermutation[powerrowsums1[[i]],powerrowsums2[[i]]],{i,1,pow}]];
rowpermssametest=Length[rowtest]==1;
If[!rowpermssametest,Return[{False,{}}]];
rowperm=rowtest[[1]];
rowmatrix=Normal[SparseArray[Transpose[{Range[Length[powerrowsums1[[1]]]],PermutationList[rowperm,Length[powerrowsums1[[1]]]]}]->1,{Length[powerrowsums1[[1]]],Length[powerrowsums1[[1]]]}]];

(*Now columns*)

tc1=Transpose[c1];tc2=Transpose[c2];
powercolsums1=Table[Table[Total[tc1[[i]]^j],{i,1,Length[tc1]}],{j,1,pow}];
powercolsums2=Table[Table[Total[tc2[[i]]^j],{i,1,Length[tc2]}],{j,1,pow}];
colsumssametest=Sort[Table[Sort[powercolsums1[[i]]],{i,1,Length[powercolsums1]}]]==Sort[Table[Sort[powercolsums2[[i]]],{i,1,Length[powercolsums2]}]];
If[!colsumssametest,Return[{False,{}}]];

coltest=DeleteDuplicates[Table[FindPermutation[powercolsums1[[i]],powercolsums2[[i]]],{i,1,pow}]];
colpermssametest=Length[coltest]==1;
If[!colpermssametest,Return[{False,{}}]];

colperm=coltest[[1]];
colmatrix=Normal[SparseArray[Transpose[{Range[Length[powercolsums1[[1]]]],PermutationList[colperm,Length[powercolsums1[[1]]]]}]->1,{Length[powercolsums1[[1]]],Length[powercolsums1[[1]]]}]];

check=(rowmatrix . c1 . Transpose[colmatrix]-c2)==(c2/._Integer->0);
If[!check,Return["Methods Insufficient"]];
Return[{True,rowmatrix,colmatrix}];
]


(* ::Subsection::Closed:: *)
(*Intersection modules*)


(* ::Subsubsection::Closed:: *)
(*Mu: compute integrating form for CI*)


CIPro`Mu::usage="Mu[ass,opt], ccomputes the integrating form for CIs.";

AssociateTo[CIPro`Private`CIProMod,"Mu"->Mu]; AssociateTo[CIPro`Private`CIProDep,"Mu"->{"Conf"}];
AssociateTo[CIPro`Private`CIProInfo,"Mu"->"The integrating differential form for the CI."];
AppendTo[CIPro`Private`CIProSection["CIs"],"Mu"];

Mu[ass_,opt___]:=Module[{confT,nP,npol,Js,i,mu,Jname},

(* basic definition *)
Jname="KFormsName"/.{opt}/.Options[CIPro];
confT=Transpose[ass["Conf"]]; {nP,npol}=Dimensions[ass["Conf"]]; 
Js=Table[Subscript[Jname, i],{i,1,nP}]; 

(* compute mu *)
If[npol==0,mu=1,mu=Product[confT[[i]] . Js,{i,1,npol}]];

mu];


(* ::Subsubsection::Closed:: *)
(*IntersecForm: compute intersection form*)


CIPro`IntersecForm::usage="IntersecForm[ass,opt], ccomputes the intersection form of a CIs.";

AssociateTo[CIPro`Private`CIProMod,"ISecForm"->IntersecForm]; AssociateTo[CIPro`Private`CIProDep,"ISecForm"->{"Conf","DimPs","AmbDim","CIDim","Mu"}];
AssociateTo[CIPro`Private`CIProInfo,"ISecForm"->"The intersection form of the CI."];
AppendTo[CIPro`Private`CIProSection["CIs"],"ISecForm"];

IntersecForm[ass_,opt___]:=Module[
  {nP,npol,Js,J,i,dPs,topform,mu,cidim,Jname,cname,J2,isecform,tv,counter,
   currentone,m,n,neededpowers,Jncoeff,currentanswer,output,Jprod,seq,int,isec},

(* basic definitions *)
Jname="KFormsName"/.{opt}/.Options[CIPro];
cname="KModuliName"/.{opt}/.Options[CIPro];
{nP,npol}=Dimensions[ass["Conf"]]; dPs=ass["DimPs"]; cidim=ass["CIDim"]; mu=Expand[ass["Mu"]];
If[cidim<=0,Return[None]];
Js=Table[Subscript[Jname, i],{i,1,nP}]; (* define standard Kahler form basis *)
tv=Table[Subscript[cname, i],{i,1,nP}]; (* define vector of Kahler parameters *)
J2=tv . Js; (* Kahler form *)

(* intersection calculation *)
topform=Product[Js[[i]]^dPs[[i]],{i,1,nP}]; (* define ambient top form *)


(* extract coefficient of top form in mu times appropriate power of Kahler form *)
(*new code here*)

(* output={};
For[counter=1,counter<=Length[mu],counter++,
currentone=topform/mu[[counter]];
If[Position[Negative[Exponent[currentone,Js]],True]=={},
neededpowers=Exponent[currentone,Js];
Jncoeff=Product[Binomial[cidim-Sum[Subscript[n, j],{j,1,i-1}],Subscript[n, i]],{i,1,nP}]/.Table[Subscript[n, i]->neededpowers[[i]],{i,1,nP}];
currentanswer=(mu[[counter]]/.Table[Js[[i]]->1,{i,1,Length[Js]}])Product[tv[[i]]^neededpowers[[i]],{i,1,nP}]Jncoeff;
AppendTo[output,currentanswer]]];
isecform=Total[output]; *)


(* old code here - this one actually works *)
Jprod=Product[Subscript[Jname, Global`i[k]],{k,1,cidim}]; (* product of Kahler forms *)
seq=Apply[Sequence,Table[{Global`i[k],1,nP},{k,1,cidim}]]; (* summation ranges *)
int=Table[mu*Jprod,Evaluate[seq]]; (* compute integrands *)
isec=Map[Coefficient[#,topform]&,int]; (* extract coefficient of top form *)
isec=Table[Coefficient[mu Jprod,topform],Evaluate[seq]]; (* compute intersection numbers *)

isecform=Expand[Coefficient[J2^cidim*mu,topform]]; (* extract coefficient of top form *)

isecform];


(* ::Subsubsection::Closed:: *)
(*Intersec: compute intersection numbers*)


CIPro`Intersec::usage="Intersec[ass,opt], ccomputes the intersection numbers of a CIs.";

AssociateTo[CIPro`Private`CIProMod,"ISec"->Intersec]; AssociateTo[CIPro`Private`CIProDep,"ISec"->{"Conf","DimPs","AmbDim","CIDim","Mu","ISecForm"}];
AssociateTo[CIPro`Private`CIProInfo,"ISec"->"The intersection numbers of the CI."];
AppendTo[CIPro`Private`CIProSection["CIs"],"ISec"];

Intersec[ass_,opt___]:=Module[{isec,isecform,cname,nP,npol,tv,dPs},

(*check computation can be performed*)
dPs=ass["DimPs"];
If[!Apply[And,Map[IntegerQ,Flatten[dPs]]],ErrorPrint["Ambient space data must all be given in terms of integers to compute this keyword."];Return[$Failed];
];

(* basic definitions *)
isecform=ass["ISecForm"]; {nP,npol}=Dimensions[ass["Conf"]];
cname="KModuliName"/.{opt}/.Options[CIPro];
tv=Table[Subscript[cname, i],{i,1,nP}];

isec=CoefficientArrays[isecform,tv,Symmetric->True]//Normal//Last; (* extract coefficients *)

isec];


(* ::Subsection::Closed:: *)
(*Characteristic classes*)


(* ::Subsubsection::Closed:: *)
(*CPoly: compute Chern class in terms of Kahler forms*)


CIPro`CCIPoly::usage="CCIPoly[ass,opt], computes Chern class of CI tangent bundle as a polynomial in basis forms.";

AssociateTo[CIPro`Private`CIProMod,"CPoly"->CCIPoly]; AssociateTo[CIPro`Private`CIProDep,"CPoly"->{"Conf","DimPs","AmbDim","CIDim","Mu"}];
AssociateTo[CIPro`Private`CIProInfo,"CPoly"->"The Chern class of the CI tangent bundle, as a polynomial in the standard forms."];
AppendTo[CIPro`Private`CIProSection["CIs"],"CPoly"];

CCIPoly[ass_,opt___]:=Module[{conf,dPs,nP,npol,Js,i,cidim,call,csym,cten,d,isec,Jname,trimmingsubs},

(* basic definitions *)
Jname="KFormsName"/.{opt}/.Options[CIPro];
conf=ass["Conf"]; dPs=ass["DimPs"]; {nP,npol}=Dimensions[conf]; cidim=ass["CIDim"];
If[!Apply[And,Map[IntegerQ,Flatten[dPs]]],ErrorPrint["Ambient space data must all be given in terms of integers to compute this keyword."];Return[$Failed];
];
isec=ass["ISec"]; Js=Table[Subscript[Jname, i],{i,1,nP}];

(* general formula for Chern classes in terms of Kahler forms *)
call=Product[(1+d*Js[[i]])^(dPs[[i]]+1),{i,1,nP}]/Product[1+Sum[conf[[i,a]]*d*Js[[i]],{i,1,nP}],{a,1,npol}];
(* expand in powers of Kahler forms *)
csym=Normal[Series[call,{d,0,cidim}]]/.d->1;

(* Trim down output to account for powers of Js vanishing due to dimensions of ambient space factors*)
trimmingsubs=Flatten[Table[Table[Js[[i]]^(dPs[[i]]+j)->0,{j,1,cidim-dPs[[i]]}],{i,1,Length[dPs]}]];

csym/.trimmingsubs];


(* ::Subsubsection::Closed:: *)
(*CCI: compute numerical version of Chern classes*)


CIPro`CCI::usage="CCI[ass,opt], computes Chern class of CI tangent bundle numerically, relative to standard basis.";

AssociateTo[CIPro`Private`CIProMod,"C"->CCI]; AssociateTo[CIPro`Private`CIProDep,"C"->{"Conf","DimPs","AmbDim","CIDim","Mu","ISecForm","ISec","CPoly"}];
AssociateTo[CIPro`Private`CIProInfo,"C"->"The Chern class of the CI numerically, relative to the standard basis."];
AppendTo[CIPro`Private`CIProSection["CIs"],"C"];

CCI[ass_,opt___]:=Module[{dPs},
dPs=ass["DimPs"];
If[!Apply[And,Map[IntegerQ,Flatten[dPs]]],ErrorPrint["Ambient space data must all be given in terms of integers to compute this keyword."];Return[$Failed];
];
Expand[ClassConvert[ass["CPoly"],ass["ISec"],ass["CIDim"],Length[ass["Conf"]]]]];


(* ::Subsubsection::Closed:: *)
(*ChCIPoly: compute Chern character in terms of Kahler forms*)


CIPro`ChCIPoly::usage="CCIPoly[ass,opt], computes Chern character of CI tangent bundle as a polynomial in basis forms.";

AssociateTo[CIPro`Private`CIProMod,"ChPoly"->ChCIPoly]; AssociateTo[CIPro`Private`CIProDep,"ChPoly"->{"Conf","DimPs","AmbDim","CIDim","Mu","CPoly"}];
AssociateTo[CIPro`Private`CIProInfo,"ChPoly"->"The Chern character of the CI tangent bundle, as a polynomial in the standard forms."];
AppendTo[CIPro`Private`CIProSection["CIs"],"ChPoly"];

ChCIPoly[ass_,opt___]:=Class2Class[ass["CPoly"],ass["CIDim"],First[Dimensions[ass["Conf"]]],ass["CIDim"],"C","Ch"];


(* ::Subsubsection::Closed:: *)
(*ChCI: compute numerical version of Chern character*)


CIPro`ChCI::usage="ChCI[ass,opt], computes Chern character of CI tangent bundle numerically, relative to standard basis.";

AssociateTo[CIPro`Private`CIProMod,"Ch"->ChCI]; AssociateTo[CIPro`Private`CIProDep,"Ch"->{"Conf","DimPs","AmbDim","CIDim","Mu","ISecForm","ISec","CPoly","ChPoly"}];
AssociateTo[CIPro`Private`CIProInfo,"Ch"->"The Chern character of the CI tangent bundle numerically, relative to the standard basis."];
AppendTo[CIPro`Private`CIProSection["CIs"],"Ch"];

ChCI[ass_,opt___]:=Expand[ClassConvert[ass["ChPoly"],ass["ISec"],ass["CIDim"],First[Dimensions[ass["Conf"]]]]];


(* ::Subsubsection::Closed:: *)
(*TdCIPoly: compute Todd class in terms of Kahler forms*)


CIPro`TdCIPoly::usage="TdCIPoly[ass,opt], computes Todd class of CI tangent bundle as a polynomial in basis forms.";

AssociateTo[CIPro`Private`CIProMod,"TdPoly"->TdCIPoly]; AssociateTo[CIPro`Private`CIProDep,"TdPoly"->{"Conf","DimPs","AmbDim","CIDim","Mu","CPoly"}];
AssociateTo[CIPro`Private`CIProInfo,"TdPoly"->"The Todd class of the CI tangent bundle, as a polynomial in the standard forms."];
AppendTo[CIPro`Private`CIProSection["CIs"],"TdPoly"];

TdCIPoly[ass_,opt___]:=Class2Class[ass["CPoly"],ass["CIDim"],First[Dimensions[ass["Conf"]]],ass["CIDim"],"C","Td"];


(* ::Subsubsection::Closed:: *)
(*TdCI: compute numerical version of Todd class*)


CIPro`TdCI::usage="TdCI[ass,opt], computes Todd class of CI tangent bundle numerically, relative to standard basis.";

AssociateTo[CIPro`Private`CIProMod,"Td"->TdCI]; AssociateTo[CIPro`Private`CIProDep,"Td"->{"Conf","DimPs","AmbDim","CIDim","Mu","ISecForm","ISec","CPoly","TdPoly"}];
AssociateTo[CIPro`Private`CIProInfo,"Td"->"The Todd class of the CI tangent bundle numerically, relative to the standard basis."];
AppendTo[CIPro`Private`CIProSection["CIs"],"Td"];

TdCI[ass_,opt___]:=Expand[ClassConvert[ass["TdPoly"],ass["ISec"],ass["CIDim"],First[Dimensions[ass["Conf"]]]]];


(* ::Subsubsection::Closed:: *)
(*EulerCI: compute Euler number*)


CIPro`EulerCI::usage="EulerCI[ass,opt], computes Euler number of CI.";

AssociateTo[CIPro`Private`CIProMod,"Euler"->EulerCI]; AssociateTo[CIPro`Private`CIProDep,"Euler"->{"Conf","DimPs","AmbDim","CIDim","Mu","ISecForm","ISec","CPoly","C"}];
AssociateTo[CIPro`Private`CIProInfo,"Euler"->"The Euler number of the CI."];
AppendTo[CIPro`Private`CIProSection["CIs"],"Euler"];

EulerCI[ass_,opt___]:=Module[{dPs,Jname,i,tf},

If[ass["CIDim"]>0,Return[Last[ass["C"]]],
  dPs=ass["DimPs"]; Jname="KFormsName"/.Options[CIPro];
  tf=Product[Subscript[Jname, i]^dPs[[i]],{i,1,Length[dPs]}];
  Return[ass["Mu"]/tf]
];
];


(* ::Subsubsection::Closed:: *)
(*KCI: compute canonical bundle*)


CIPro`KCI::usage="KCI[ass,opt], compute canonical bundle of CI.";

AssociateTo[CIPro`Private`CIProMod,"K"->KCI]; AssociateTo[CIPro`Private`CIProDep,"K"->{"Conf","DimPs"}];
AssociateTo[CIPro`Private`CIProInfo,"K"->"The canonical bundle of the CI."];
AppendTo[CIPro`Private`CIProSection["CIs"],"K"];

KCI[ass_,opt___]:=Map[List,Map[Total,ass["Conf"]]-ass["DimPs"]-1];


(* ::Subsection::Closed:: *)
(*Defining equations*)


(* ::Subsubsection::Closed:: *)
(*MMonList: list of monomials*)


CIPro`MMonList::usage="MMonList[ass,opt], produce lists of monomials with multi-degrees specified by the CI.";

AssociateTo[CIPro`Private`CIProMod,"MonList"->MMonList]; AssociateTo[CIPro`Private`CIProDep,"MonList"->{"Conf","DimPs","AmbCoords"}];
AssociateTo[CIPro`Private`CIProInfo,"MonList"->"A list of monomial lists with multi-degrees specified by the CI."];
AppendTo[CIPro`Private`CIProSection["CIs"],"MonList"];

MMonList[ass_,opt___] := Module[{var,deg,a,i},

var=ass["AmbCoords"]; deg=Transpose[ass["Conf"]];
If[!Apply[And,Map[IntegerQ,Flatten[deg]]],ErrorPrint["CI data must all be given in terms of integers to compute this keyword."];Return[$Failed];
];

Table[Switch[var,{},{},_,Map[Apply[Times,#]&,Tuples[Table[MList[deg[[i,a]],var[[a]]],{a,1,Length[deg[[i]]]}]]]],{i,1,Length[deg]}]];


CIPro`MList::usage="MList[deg,var], produce lists of monomials with given degree in specified variables.";

MList[deg_Integer, var_List] := Module[{powers,part},

If[deg<0,Return[{0}]];
If[var=={},Return[{}]];

part=IntegerPartitions[deg];
part=Select[part,Length[#]<=Length[var]&];

powers=DeleteDuplicates[Flatten[Map[Permutations,Map[PadRight[#,Length[var]]&,part]],1]];

Map[Apply[Times, #] &, Map[Power[var, #] &, powers]]];


(* ::Subsubsection::Closed:: *)
(*DefEqs: defining equations of CI*)


CIPro`DefEqs::usage="DefEqs[ass,opt], produce defining equations for a CI.";

AssociateTo[CIPro`Private`CIProMod,"DefEqs"->DefEqs]; AssociateTo[CIPro`Private`CIProDep,"DefEqs"->{"Conf","DimPs","AmbCoords","MonList"}];
AssociateTo[CIPro`Private`CIProInfo,"DefEqs"->"A list of the CI defining equations (taken from \"InvMon\" if it exists, otherwise generic). Relevant options are \"CoeffType\" and \"CoeffRange\", see ?CIPropOptions."];
AppendTo[CIPro`Private`CIProSection["CIs"],"DefEqs"];

DefEqs[ass_,opt___]:=Module[{plst,eqs,var,ambcoords},

eqs="Eqs"/.{opt}/.Options[CIPro`CIProp]; 
If[eqs===None,
 If[KeyExistsQ[ass,"InvMon"],plst=CIPro`InvDefEqs[ass,opt],plst=CIPro`GenericDefEqs[ass,opt]],
 plst=eqs;
];

(* basic checking if coordinates in defining equations are the agreed ambient space coordiantes *)
var=Sort[Variables[plst]];
ambcoords=Sort[Flatten[ass["AmbCoords"]]];
If[!SubsetQ[var,ambcoords],ErrorPrint["Coordnates in defining equations do not match the agreed ambient space coordiantes in \"AmbCoords\"."]];
 
plst];


CIPro`GenericDefEqs::usage="GenericDefEqs[ass,opt], produce generic defining equations for a CI.";

GenericDefEqs[ass_,opt___]:=Module[{coeffrange,coefftype,monlist,len,clst,i,j,plst},

(* options *)
coeffrange="CoeffRange"/.{opt}/.Options[CIProp];
coefftype="CoeffType"/.{opt}/.Options[CIProp];
monlist=ass["MonList"]; len=Map[Length,monlist];

(* coefficients *)
clst=Switch[coefftype,
  "Integer",Table[RandomInteger[coeffrange,len[[i]]],{i,1,Length[len]}],
  "Real",Table[RandomReal[coeffrange,len[[i]]],{i,1,Length[len]}],
  "CInteger",Table[RandomInteger[coeffrange,len[[i]]]+I RandomInteger[coeffrange,len[[i]]],{i,1,Length[len]}],
  "CReal",Table[RandomReal[coeffrange,len[[i]]]+I RandomReal[coeffrange,len[[i]]],{i,1,Length[len]}],
  _,Table[Subscript[coefftype, i,j],{i,1,Length[len]},{j,1,len[[i]]}]
];

(* compute defining equations *)
plst=Table[clst[[i]] . monlist[[i]],{i,1,Length[monlist]}];
plst];


CIPro`InvDefEqs::usage="InvDefEqs[ass,opt], produce defining equations for a CI invariant under a symmetry.";

InvDefEqs[ass_,opt___]:=Module[{coeffrange,coefftype,invmon,len,clst,invpols},

(* options *)
coeffrange="CoeffRange"/.{opt}/.Options[CIProp];
coefftype="CoeffType"/.{opt}/.Options[CIProp];
invmon=ass["InvMon"]; len=Length[invmon];

(* coefficients *)
clst=Switch[coefftype,
  "Integer",RandomInteger[coeffrange,len],
  "Real",RandomReal[coeffrange,len],
  "CInteger",RandomInteger[coeffrange,len]+I RandomInteger[coeffrange,len],
  "CReal",RandomReal[coeffrange,len]+I RandomReal[coeffrange,len],
  _,Table[Subscript[coefftype, i],{i,1,len}]
];

invpols=Sum[clst[[i]]*invmon[[i]],{i,1,len}];

invpols];


(* ::Subsubsection::Closed:: *)
(*SingularityCheck : check smoothness of  defining relations*)


CIPro`SingularityCheck::usage="SingularityCheck[ass,opt], checks if the CI is singular.";

AssociateTo[CIPro`Private`CIProMod,"Singular"->SingularityCheck]; AssociateTo[CIPro`Private`CIProDep,"Singular"->{"Conf","DimPs","AmbCoords","MonList","DefEqs"}];
AssociateTo[CIPro`Private`CIProInfo,"Singular"->"True if CI is singular, False if CI is smooth. Relevant option \"FieldChar\", see ?CIPropOptions."];
AppendTo[CIPro`Private`CIProSection["CIs"],"Singular"];

SingularityCheck[ass_,opt___]:=Module[{locustest,cy,definingreln,gb,fieldchar,ambcoords,test,count,prepatches,patches,badger,currentps,currentcoord,currentH,currentMinors,tocheckgens,i,j},

(*basic definitions*)
cy=ass["Conf"];
definingreln=ass["DefEqs"];
fieldchar="FieldChar"/.{opt}/.Options[CIPro`CIProp];
ambcoords=AmbCoords[ass];

locustest=KeyExistsQ[ass,"SingularLocus"];
If[!locustest,

prepatches=Tuples[ambcoords];
patches=Table[Table[prepatches[[i]][[j]]->1,{j,1,Length[prepatches[[i]]]}],{i,1,Length[prepatches]}];

test=True;

For[count=1,count<=Length[patches],count++,
badger=False;
currentps=Flatten[{definingreln/.patches[[count]]}];
currentcoord=DeleteCases[Flatten[ambcoords]/.patches[[count]],1];
currentH=Map[D[currentps,#]&,currentcoord];
currentMinors=Minors[currentH,Min[Length[currentps],Length[currentcoord]]];
tocheckgens=Flatten[{currentps,currentMinors}];

gb=GroebnerBasis[tocheckgens,currentcoord,Modulus->fieldchar];

If[gb!={1},test=False];
If[!test,badger="True"];
If[!test,Break[]]
];,

patches=ass["SingularLocus"][[2]];
For[count=1,count<=Length[patches],count++,
badger=False;
currentcoord=DeleteCases[Flatten[ambcoords]/.patches[[count]],1];
tocheckgens=Flatten[{currentps,ass["SingularLocus"][[1]][[count]]}];

gb=GroebnerBasis[tocheckgens,currentcoord,Modulus->fieldchar];

If[gb!={1},test=False];
If[!test,badger="True"];
If[!test,Break[]]
]
];

badger
];


(* ::Subsubsection::Closed:: *)
(*SingularityLocus : provide the nodal variety associated to defining relations*)


CIPro`SingularityLocus::usage="SingularityLocus[ass,opt], provies the nodal variety associated to CI.";

AssociateTo[CIPro`Private`CIProMod,"SingularLocus"->SingularityLocus]; AssociateTo[CIPro`Private`CIProDep,"SingularLocus"->{"Conf","DimPs","AmbCoords","MonList","DefEqs"}];
AssociateTo[CIPro`Private`CIProInfo,"SingularLocus"->"Defining equations of the nodal variety for a CI."];
AppendTo[CIPro`Private`CIProSection["CIs"],"SingularLocus"];

SingularityLocus[ass_,opt___]:=Module[{gblist,cy,definingreln,ambcoords,count,prepatches,patches,currentps,currentcoord,currentH,currentMinors,tocheckgens,i,j},

(*basic definitions*)
cy=ass["Conf"];
definingreln=ass["DefEqs"];
ambcoords=AmbCoords[ass];

prepatches=Tuples[ambcoords];
patches=Table[Table[prepatches[[i]][[j]]->1,{j,1,Length[prepatches[[i]]]}],{i,1,Length[prepatches]}];
gblist={};

For[count=1,count<=Length[patches],count++,

currentps=Flatten[{definingreln/.patches[[count]]}];
currentcoord=DeleteCases[Flatten[ambcoords]/.patches[[count]],1];
currentH=Map[D[currentps,#]&,currentcoord];
currentMinors=Minors[currentH,Min[Length[currentps],Length[currentcoord]]];
tocheckgens=Flatten[{currentps,currentMinors}];

AppendTo[gblist,tocheckgens]
];
{gblist,patches}
];


(* ::Subsection::Closed:: *)
(*Instanton numbers*)


(* ::Subsubsection::Closed:: *)
(*GVInvariants: compute genus 0 GV invariants*)


CIPro`GVInvariants::usage="GVInvariants[ass,opt], compute the GV invariants (CY 3-folds onle).";

AssociateTo[CIPro`Private`CIProMod,"GVInv"->GVInvariants]; AssociateTo[CIPro`Private`CIProDep,"GVInv"->{"Conf","AmbDim","DimPs","CIDim","CY"}];
AssociateTo[CIPro`Private`CIProInfo,"GVInv"->"Genus 0 Gopakumar-Vafa invariants (for CY three-folds only), computed with Albrecht Klemm's code, based on the papers by S. Hosono, A. Klemm, S. Theisen and S.-T. Yau, \!\(\*TemplateBox[{RowBox[{RowBox[{\"https\", \":\"}], \"//\", RowBox[{RowBox[{RowBox[{RowBox[{\"arxiv\", \".\", \"org\"}], \"/\", \"pdf\"}], \"/\", \"hep\"}], \"-\", RowBox[{RowBox[{\"th\", \"/\", \"9308122.\"}], \"pdf\"}]}]}], {URL[\"https://arxiv.org/pdf/hep-th/9308122.pdf\"], None}, \"https://arxiv.org/pdf/hep-th/9308122.pdf\", \"HyperlinkActionRecycled\", {\"HyperlinkActive\"}, BaseStyle -> {\"Hyperlink\"}, HyperlinkAction -> \"Recycled\"},\"HyperlinkTemplate\"]\) and \!\(\*TemplateBox[{RowBox[{RowBox[{\"https\", \":\"}], \"//\", RowBox[{RowBox[{RowBox[{RowBox[{\"arxiv\", \".\", \"org\"}], \"/\", \"pdf\"}], \"/\", \"hep\"}], \"-\", RowBox[{RowBox[{\"th\", \"/\", \"9406055.\"}], \"pdf\"}]}]}], {URL[\"https://arxiv.org/pdf/hep-th/9406055.pdf\"], None}, \"https://arxiv.org/pdf/hep-th/9406055.pdf\", \"HyperlinkActionRecycled\", {\"HyperlinkActive\"}, BaseStyle -> {\"Hyperlink\"}, HyperlinkAction -> \"Recycled\"},\"HyperlinkTemplate\"]\). For additional information on higher-genus invariants see \!\(\*TemplateBox[{RowBox[{RowBox[{\"http\", \":\"}], \"//\", RowBox[{RowBox[{\"www\", \".\", \"th\", \".\", \"physik\", \".\", \"uni\"}], \"-\", RowBox[{RowBox[{RowBox[{RowBox[{RowBox[{\"bonn\", \".\", \"de\"}], \"/\", \"th\"}], \"/\", \"Groups\"}], \"/\", \"klemm\"}], \"/\", RowBox[{\"data\", \".\", \"php\"}]}]}]}], {URL[\"http://www.th.physik.uni-bonn.de/th/Groups/klemm/data.php\"], None}, \"http://www.th.physik.uni-bonn.de/th/Groups/klemm/data.php\", \"HyperlinkActionRecycled\", {\"HyperlinkActive\"}, BaseStyle -> {\"Hyperlink\"}, HyperlinkAction -> \"Recycled\"},\"HyperlinkTemplate\"]\). Relevant option is \"MaxDef\", see ?CIPropOptions."];
AppendTo[CIPro`Private`CIProSection["CIs"],"GVInv"];

GVInvariants[ass_,opt___]:=Module[{maxdeg,conf,nP,classes,res,dP},

(* options *)
maxdeg="MaxDeg"/.{opt}/.Options[CIProp];
conf=ass["Conf"]; nP=Length[conf];
If[!ass["CY"] || ass["CIDim"]!=3,
  ErrorPrint["GV invariants are only computed for CY 3-folds."];
  Return[None];
];  
(*Check input*)
dP=ass["DimPs"];
If[!Apply[And,Map[IntegerQ,Flatten[{dP,conf}]]],ErrorPrint["CI data must all be given in terms of integers to compute this keyword."];Return[$Failed];
];
(* call Albrecht's code *)
inst3`Private`getInstantons[conf,maxdeg,False];
(* process output *)
classes=Tuples[Table[i,{i,0,maxdeg}],nP];
classes=DeleteCases[Select[classes,Total[#]<=maxdeg &],Table[0,{nP}]];
res=Table[classes[[i]]->Apply[inst3`Private`nrc,classes[[i]]],{i,1,Length[classes]}];
res=res/.inst3`Private`nrc[__]->"0";

res];


(* ::Subsection::Closed:: *)
(*Hilbert series*)


(* ::Subsubsection::Closed:: *)
(*HilbertSeries: compute Hilbert series for CI*)


CIPro`HilbertSeries::usage="HilbertSeries[ass,opt], computes the Hilbert series for the CI.";

AssociateTo[CIPro`Private`CIProMod,"HilbertSeries"->HilbertSeries]; AssociateTo[CIPro`Private`CIProDep,"HilbertSeries"->{"Conf","DimPs"}];
AssociateTo[CIPro`Private`CIProInfo,"HilbertSeries"->"Compute Hilbert series of the multi-graded ring associated to the CI. Relevant option is \"HilbertFormat\", see ?CIPropOptions."];
AppendTo[CIPro`Private`CIProSection["CIs"],"HilbertSeries"];

HilbertSeries[ass_,opt___]:=Module[{format,cn,vec,conf,m,K,cT,freehilbert,dP,hilbertseries,pol},

(* options *)
format="HilbertFormat"/.{opt}/.Options[CIProp];
conf=ass["Conf"]; cT=Transpose[conf]; {m,K}=Dimensions[conf];
cn="KModuliName"/.Options[CIPro]; vec=Table[Subscript[cn, i],{i,1,m}];
dP=ass["DimPs"];

(*Check format if expansion requested*)
If[IntegerQ[format],If[!Apply[And,Map[IntegerQ,Flatten[{conf,dP}]]],ErrorPrint["CI data must all be given in terms of integers to compute this keyword."];Return[$Failed];
]];


(* free hilbert series *)
freehilbert=Product[1/(1-Subscript[cn, i])^(dP[[i]]+1),{i,1,Length[dP]}];

(* Hilbert series of complete intersection *)
If[K==0,pol=1,pol=Product[1-Apply[Times,vec^cT[[i]]],{i,1,K}]];
hilbertseries=pol*freehilbert;

CIPro`HilbertExpand[dP,cn,hilbertseries,format]];


(* ::Subsubsection::Closed:: *)
(*HilbertExpand: auxiliary module to present Hilbert series in different formats*)


CIPro`HilbertExpand::usage="HilbertExpand[dP,hilb,outformat], to represent the Hilbert series hilb in different formats.";

HilbertExpand[dP_,cn_,hilb_,outformat_]:=Module[{degs,max,hilbex,arg,vec,mlst,i,outf},
If[outformat=={},Return[hilb]];outf=outformat;
If[MatrixQ[outf],degs=outf];
If[IntegerQ[outf],outf={0,outf}];
If[VectorQ[outf],degs=Tuples[Table[i,{i,First[outf],Last[outf]}],Length[dP]]];
degs=DeleteCases[degs,Table[0,{Length[dP]}]];
vec=Table[Subscript[cn, i],{i,1,Length[dP]}];

max=Max[Flatten[degs]];
arg=Apply[Sequence,Table[{vec[[i]],0,max},{i,1,Length[dP]}]];
hilbex=Expand[Normal[Series[hilb,arg]]];
mlst=Table[Apply[Times,vec^degs[[i]]],{i,1,Length[degs]}];
Sum[(Coefficient[hilbex,mlst[[i]]]/.Subscript[cn, _]->0)*mlst[[i]],{i,1,Length[degs]}]+(hilbex/.Subscript[cn, _]->0)];


(* ::Section::Closed:: *)
(*Modules for matrix groups*)


(* ::Subsection::Closed:: *)
(*Basic modules*)


(* ::Subsubsection::Closed:: *)
(*auxiliary modules*)


CIPro`MD::usage="MD[matlst], computes an enhanced dot product for matrix lists.";

MD[glst_]:=MapThread[Dot,glst];


CIPro`ArrangeGen::usage="ArrangeGen[ass], brings group generators into a standard form.";

ArrangeGen[ass_]:=Module[{gen},
gen=ass["Gen"]; If[Length[gen]==0,Return[{}]];
If[MatrixQ[First[gen]],gen=Map[List,gen]];
gen];


(* ::Subsubsection::Closed:: *)
(*Gen: define default generators*)


CIPro`Gen::usage="Gen[ass,opt], defines default generators.";

AssociateTo[CIPro`Private`CIProMod,"Gen"->Gen]; AssociateTo[CIPro`Private`CIProDep,"Gen"->{}];
AssociateTo[CIPro`Private`CIProInfo,"Gen"->"The generators of a matrix group."];
AppendTo[CIPro`Private`CIProSection["Symmetries"],"Gen"];

Gen[ass_,opt___]:=Module[{gen,pdim,m,K},

If[KeyExistsQ[ass,"Conf"] && KeyExistsQ[ass,"DimPs"],
  pdim=Total[ass["DimPs"]]+Length[ass["DimPs"]];
  {m,K}=Dimensions[ass["Conf"]];
  gen={{IdentityMatrix[pdim],IdentityMatrix[K]}},
  gen={{{{1,0,0,0,0},{0,E^((2 I \[Pi])/5),0,0,0},{0,0,E^((4 I \[Pi])/5),0,0},{0,0,0,E^(-((4 I \[Pi])/5)),0},{0,0,0,0,E^(-((2 I \[Pi])/5))}},{{1}}}};
];

gen];


(* ::Subsubsection::Closed:: *)
(*GenOrder: compute order of generators*)


CIPro`GenOrder::usage="GenOrder[ass,opt], computes order of generators.";

AssociateTo[CIPro`Private`CIProMod,"GenOrder"->GenOrder]; AssociateTo[CIPro`Private`CIProDep,"GenOrder"->{"Gen"}];
AssociateTo[CIPro`Private`CIProInfo,"GenOrder"->"A list with the orders of the group generators."];
AppendTo[CIPro`Private`CIProSection["Symmetries"],"GenOrder"];

GenOrder[ass_,opt___]:=Module[{gen,id,ord,i,g,gpow,k,isid,ordmax},

(* basics *)
ordmax="MaxGenOrder"/.{opt}/.Options[CIPro];
gen=ArrangeGen[ass];
If[Length[gen]==0,Return[{}]];
id=Map[IdentityMatrix[Length[#]]&,First[gen]];
ord=Table[0,{Length[gen]}];

For[i=1,i<=Length[gen],i++,
 g=gen[[i]]; gpow=id; k=0; isid=False;
 While[!isid && k<ordmax,
   gpow=MD[{gpow,g}]; k++; 
   isid=Total[Abs[Flatten[gpow-id]]]<10^(-10);
  ];
  If[isid,ord[[i]]=k,ord[[i]]=None];
];  
  
ord];


(* ::Subsubsection::Closed:: *)
(*Abelian: check if matrix group is Abelian*)


CIPro`Abelian::usage="Abelian[ass,opt], checks if matrix group is Abelian.";

AssociateTo[CIPro`Private`CIProMod,"Abelian"->Abelian]; AssociateTo[CIPro`Private`CIProDep,"Abelian"->{"Gen"}];
AssociateTo[CIPro`Private`CIProInfo,"Abelian"->"Whether the matrix group is Abelian."];
AppendTo[CIPro`Private`CIProSection["Symmetries"],"Abelian"];

Abelian[ass_,opt___]:=Module[{gen,i,j,ablst},
(* seteup *)
gen=ArrangeGen[ass];
If[Length[gen]<=1,Return[True]];
(* check commutativity of generators *)
ablst=Table[Total[Abs[Flatten[MD[{gen[[i]],gen[[j]]}]-MD[{gen[[j]],gen[[i]]}]]]]<10^(-10),{i,1,Length[gen]-1},{j,i+1,Length[gen]}];
Apply[And,Flatten[ablst]]];


(* ::Subsubsection::Closed:: *)
(*ProjAbelian: check if matrix group is projectively Abelian*)


CIPro`ProjAbelian::usage="ProjAbelian[ass,opt], checks if matrix group is projectively Abelian.";

AssociateTo[CIPro`Private`CIProMod,"ProjAbelian"->ProjAbelian]; AssociateTo[CIPro`Private`CIProDep,"ProjAbelian"->{"Gen","Conf","DimPs"}];
AssociateTo[CIPro`Private`CIProInfo,"ProjAbelian"->"Whether the matrix group is projectively Abelian."];
AppendTo[CIPro`Private`CIProSection["Symmetries"],"ProjAbelian"];

ProjAbelian[ass_,opt___]:=Module[{gen,dimPs,i,j,com,rest,abelian,c1,c2,c1rest,c2rest},
(* seteup *)
gen=ArrangeGen[ass];
If[Length[gen]<=1,Return[True]];
dimPs=ass["DimPs"];
(* check if Abelian assuming prjective multiplication in first factor *)
abelian=True; 
For[i=1,i<Length[gen],i++,
  For[j=i+1,j<=Length[gen],j++,
    c1=MD[{gen[[i]],gen[[j]]}];c2=MD[{gen[[i]],gen[[j]]}];
    c1rest=Rest[c1]; c2rest=Rest[c2];
    If[Length[c1rest]>0,abelian=abelian && (Total[Abs[Flatten[c1rest-c2rest]]]<10^(-10))];
    If[abelian,abelian=abelian && MatProjEquiv[First[c1],First[c2],dimPs+1]];
  ];
];    

abelian]


(* ::Subsection::Closed:: *)
(*Generating the group*)


(* ::Subsubsection::Closed:: *)
(*GenGroup: generate group from generators*)


CIPro`GenGroup::usage="GenGroup[ass,opt], generates group from generators.";

AssociateTo[CIPro`Private`CIProMod,"Group"->GenGroup]; AssociateTo[CIPro`Private`CIProDep,"Group"->{"Gen"}];
AssociateTo[CIPro`Private`CIProInfo,"Group"->"The matrix group freely generated from the generators. Thanks to Kit Fraser-Taliente for implementing this."];
AppendTo[CIPro`Private`CIProSection["Symmetries"],"Group"];

GenGroup[ass_,opt___]:=Module[{appendGroup,group,stack,scanElm,gens},
gens=ArrangeGen[ass];
stack=CreateDataStructure["Stack"];
group=Association[Thread[gens->True]];
stack["PushList",gens];
appendGroup[elm_]:=If[MissingQ[group[elm]],AssociateTo[group,elm->True];
stack["Push",elm]];
While[stack["Length"]>0,scanElm=stack["Pop"];appendGroup/@(MD[{scanElm,#}]&/@gens);];
DeleteDuplicatesBy[Keys@group,N[#,10]&]];


(* ::Subsubsection::Closed:: *)
(*Order: order of the group*)


CIPro`GOrder::usage="GOrder[ass,opt], computes the group order.";

AssociateTo[CIPro`Private`CIProMod,"Order"->GOrder]; AssociateTo[CIPro`Private`CIProDep,"Order"->{"Gen","Group"}];
AssociateTo[CIPro`Private`CIProInfo,"Order"->"The order of the group."];
AppendTo[CIPro`Private`CIProSection["Symmetries"],"Order"];

GOrder[ass_,opt___]:=Length[ass["Group"]];


(* ::Subsubsection::Closed:: *)
(*ProjTrivialGroup: find projectively trivial subgroup*)


CIPro`ProjTrivialGroup::usage="ProjTrivialGroup[ass,opt], finds the projectively trivial subgroup.";

AssociateTo[CIPro`Private`CIProMod,"ProjTrivialGroup"->ProjTrivialGroup]; AssociateTo[CIPro`Private`CIProDep,"ProjTrivialGroup"->{"Gen","Group","DimPs"}];
AssociateTo[CIPro`Private`CIProInfo,"ProjTrivialGroup"->"Finds the subgroup which is (multi-) projectively trivial."];
AppendTo[CIPro`Private`CIProSection["Symmetries"],"ProjTrivialGroup"];

ProjTrivialGroup[ass_,opt___]:=Module[{group,dPs,projgroup},

group=ass["Group"]; dPs=ass["DimPs"];

Select[group,MatProjTrivial[First[#],dPs+1]&]];


(* ::Subsubsection::Closed:: *)
(*ProjTrivialOrder*)


CIPro`ProjTrivialOrder::usage="ProjTrivialOrder[ass,opt], finds the order of the projectively trivial subgroup.";

AssociateTo[CIPro`Private`CIProMod,"ProjTrivialOrder"->ProjTrivialOrder]; AssociateTo[CIPro`Private`CIProDep,"ProjTrivialOrder"->{"Gen","Group","DimPs","ProjTrivialGroup"}];
AssociateTo[CIPro`Private`CIProInfo,"ProjTrivialOrder"->"Finds the order of the subgroup which is (multi-) projectively trivial."];
AppendTo[CIPro`Private`CIProSection["Symmetries"],"ProjTrivialOrder"];

ProjTrivialOrder[ass_,opt___]:=Module[{},

Length[ass["ProjTrivialGroup"]]];


(* ::Subsubsection::Closed:: *)
(*ProjGenGroup: generate projective group from generators*)


CIPro`ProjGenGroup::usage="ProjGenGroup[ass,opt], generates the projective group.";

AssociateTo[CIPro`Private`CIProMod,"ProjGroup"->ProjGenGroup]; AssociateTo[CIPro`Private`CIProDep,"ProjGroup"->{"Gen","Group","DimPs","ProjTrivialGroup"}];
AssociateTo[CIPro`Private`CIProInfo,"ProjGroup"->"The projective matrix group freely generated from the generators."];
AppendTo[CIPro`Private`CIProSection["Symmetries"],"ProjGroup"];

ProjGenGroup[ass_,opt___]:=Module[{group,projgroup,ptgroup,g,class},

group=ass["Group"]; ptgroup=ass["ProjTrivialGroup"];
projgroup={};

While[Length[group]>0,
 g=First[group];
 class=Map[MD[{g,#}]&,ptgroup];
 group=Complement[group,class];
 projgroup=Append[projgroup,class];
]; 

projgroup];


(* ::Subsubsection::Closed:: *)
(*ProjOrder: order of projectively generated group*)


CIPro`ProjOrder::usage="ProjOrder[ass,opt], computes the order of the projective group.";

AssociateTo[CIPro`Private`CIProMod,"ProjOrder"->ProjOrder]; AssociateTo[CIPro`Private`CIProDep,"ProjOrder"->{"Gen","Group","DimPs","ProjTrivialGroup"}];
AssociateTo[CIPro`Private`CIProInfo,"ProjOrder"->"The order of the projectively generated group."];
AppendTo[CIPro`Private`CIProSection["Symmetries"],"ProjOrder"];

ProjOrder[ass_,opt___]:=Module[{},

Length[ass["Group"]]/Length[ass["ProjTrivialGroup"]]];


(* ::Subsection::Closed:: *)
(*Generate associated permutation group*)


(* ::Subsubsection::Closed:: *)
(*PermGroupGen: extract permutation group associated to a group*)


CIPro`PermGroupGen::usage="PermGroupGen[ass,opt], extract permutation group associated to a group.";

AssociateTo[CIPro`Private`CIProMod,"PermGroupGen"->PermGroupGen]; AssociateTo[CIPro`Private`CIProDep,"PermGroupGen"->{"Gen","DimPs"}];
AssociateTo[CIPro`Private`CIProInfo,"PermGroupGen"->"The permutation group associated to a matrix group."];
AppendTo[CIPro`Private`CIProSection["Symmetries"],"PermGroupGen"];

PermGroupGen[ass_,opt___]:=Module[{genlst,gen,dimPs,dim,i,pgenlst,pgen},

(* options *)
genlst=ArrangeGen[ass]; dim=Length[First[genlst]];
dimPs=ass["DimPs"]+1;

pgenlst={};
For[i=1,i<=Length[genlst],i++,
  gen=genlst[[i]];
  pgen={PermMatrix[First[gen],dimPs]};
  If[Length[gen]>1,pgen=Append[pgen,PermMatrix[gen[[2]],Table[1,{Length[gen[[2]]]}]]]];
  pgenlst=Append[pgenlst,pgen];
];  
  

pgenlst];


(* ::Section::Closed:: *)
(*Modules for CIs and symmetries*)


(* ::Subsection::Closed:: *)
(*Basic modules*)


(* ::Subsubsection::Closed:: *)
(*ConfInvQ: Check if configuration matrix is invariant under symmetry*)


CIPro`ConfInvQ::usage="ConfInvQ[ass,opt], checks if a configuration matrix is invariant under a symmetry.";

AssociateTo[CIPro`Private`CIProMod,"ConfInvQ"->ConfInvQ]; AssociateTo[CIPro`Private`CIProDep,"ConfInvQ"->{"Conf","DimPs","Gen","PermGroupGen"}];
AssociateTo[CIPro`Private`CIProInfo,"ConfInvQ"->"Checks if a configuration matrix is invariant under a symmetry."];
AppendTo[CIPro`Private`CIProSection["CIs & Symmetries"],"ConfInvQ"];

ConfInvQ[ass_,opt___]:=Module[{conf,dimPs,pgen,i,dimok,confok,pgenlst,pconf},

(* basic definitions *)
conf=ass["Conf"]; dimPs=ass["DimPs"];
pgenlst=ass["PermGroupGen"];

(* check if dimensions are consistent with permutations *)
dimok=Apply[And,Table[pgenlst[[i,1]] . dimPs==dimPs,{i,1,Length[pgenlst]}]];
If[!dimok, Return[False]];

(* check if configuration matrix is consistent with permutations *)
confok=True; i=i;
While[confok && i<=Length[pgen],
  pgen=pgenlst[[i]];
  pconf=First[pgen] . conf;
  If[Length[pgen]>1,pconf=pconf . pgen[[2]]];
  confok=confok && (pconf==conf); i++;
];  

confok];


(* ::Subsubsection::Closed:: *)
(*InvQ: Check if defining equations are invariant under symmetry*)


CIPro`InvQ::usage="InvQ[ass,opt], checks if defining equations are invariant under a symmetry.";

AssociateTo[CIPro`Private`CIProMod,"InvQ"->InvQ]; AssociateTo[CIPro`Private`CIProDep,"InvQ"->{"Conf","DimPs","AmbCoords","MonList","DefEqs","Gen"}];
AssociateTo[CIPro`Private`CIProInfo,"InvQ"->"Checks if defining equations are invariant under symmetry."];
AppendTo[CIPro`Private`CIProSection["CIs & Symmetries"],"InvQ"];

InvQ[ass_,opt___]:=Module[{gen,p,inv,i,g,gcoord,gpol,coords,dp},

gen=ass["Gen"]; p=ass["DefEqs"]; coords=ass["AmbCoords"];

inv=True; i=1; 
While[inv && i<=Length[gen],
  g=gen[[i]]; gcoord={{1}}; gpol={{1}};
  If[MatrixQ[g],gcoord=g; gpol=IdentityMatrix[Length[p]],
    If[Length[g]==1,gcoord=g[[1]]; gpol=IdentityMatrix[Length[p]]];
    If[Length[g]>=2, gcoord=g[[1]]; gpol=g[[2]]];
  ];
  dp=Simplify[gpol . Map[TransformPoly[#,coords,gcoord]&,p]-p];
  If[dp=!=Table[0,{Length[p]}], inv=False];
  i++;
];  

inv];


(* ::Subsection::Closed:: *)
(*Invariant building blocks and polynomials*)


(* ::Subsubsection::Closed:: *)
(*InvMon: construct invariant polynomial building blocks for a symmetry*)


CIPro`InvMon::usage="InvMon[ass,opt], contructs invariant polynomial building blocks for a symmetry.";

AssociateTo[CIPro`Private`CIProMod,"InvMon"->InvMon]; AssociateTo[CIPro`Private`CIProDep,"InvMon"->{"Conf","DimPs","AmbCoords","MonList","Gen","Group"}];
AssociateTo[CIPro`Private`CIProInfo,"InvMon"->"Constructs invariant polynomial building blocks for a symmetry."];
AppendTo[CIPro`Private`CIProSection["CIs & Symmetries"],"InvMon"];

InvMon[ass_,opt___]:=Module[{monlst,tmonlst,coords,group,invlst,mon,inv,i,K,vlst,olst,monlen,invfinal},

(* basic definitions *)
monlst=ass["MonList"]; tmonlst=Tuples[monlst];
K=Length[monlst];
coords=ass["AmbCoords"]; group=ass["Group"];

(* find invariants by applying the Reynolds operator to all monomials *)
invlst={};
For[i=1,i<=Length[tmonlst],i++,
  mon=tmonlst[[i]];
  inv=ReynoldsPoly[mon,coords,group];
  invlst=Append[invlst,inv];
];  

(* extract vectors and row reduce *)
invlst=DeleteCases[DeleteDuplicates[invlst],Table[0,{K}]];
vlst=Table[Flatten[MapThread[Coefficient,{invlst[[i]],monlst}]],{i,1,Length[invlst]}];
olst=RowReduce[vlst];

(* convert back into polynomials *)
monlen=Map[Length,monlst]; olst=Map[TakeList[#,monlen]&,olst];
invfinal=Table[Table[olst[[i,j]] . monlst[[j]],{j,1,Length[monlst]}],{i,1,Length[olst]}];
invfinal=DeleteCases[DeleteDuplicates[invfinal],Table[0,{K}]];

invfinal];


(* ::Section::Closed:: *)
(*Modules for line bundle sums on CIs*)


(* ::Subsection::Closed:: *)
(*Basic modules*)


(* ::Subsubsection::Closed:: *)
(*LBS: default line bundle sum*)


CIPro`LBS::usage="LBS[ass,opt], provides a default line bundle sum.";

AssociateTo[CIPro`Private`CIProMod,"LBS"->DefLBS]; AssociateTo[CIPro`Private`CIProDep,"LBS"->{}];
AssociateTo[CIPro`Private`CIProInfo,"LBS"->"A line bundle sum as a matrix which each column representing a line bundle."];
AppendTo[CIPro`Private`CIProSection["CIs & LineSums"],"LBS"];

DefLBS[ass_,opt___]:=Module[{lbs},

lbs={{0}};
If[KeyExistsQ[ass,"Conf"],lbs=Table[{0},{Length[ass["Conf"]]}]];
If[KeyExistsQ[ass,"DimPs"],lbs=Table[{0},{Length[ass["DimPs"]]}]];

lbs];


(* ::Subsubsection::Closed:: *)
(*LBSRank: rank of a line bundle sum*)


CIPro`LBSRank::usage="LBSRank[ass,opt], determines rank of a line bundle sum.";

AssociateTo[CIPro`Private`CIProMod,"LBSRank"->LBSRank]; AssociateTo[CIPro`Private`CIProDep,"LBSRank"->{"LBS"}];
AssociateTo[CIPro`Private`CIProInfo,"LBSRank"->"The rank of a line bundle sum."];
AppendTo[CIPro`Private`CIProSection["CIs & LineSums"],"LBSRank"];

LBSRank[ass_,opt___]:=Length[Transpose[ass["LBS"]]];


(* ::Subsection::Closed:: *)
(*Characteristic classes*)


(* ::Subsubsection::Closed:: *)
(*ChLBPoly: Chern character of a line bundle (auxiliary)*)


CIPro`ChLBPoly::usage="ChLBPoly[lb,cidim], computes the Chern character of a single line bundle in terms of basis forms.";

ChLBPoly[lb_(*/;VectorQ[lb,IntegerQ]*),cidim_]:=Module[{nP,Jname,Js,i,c1,predim,dim,p,ch}, (*integer requirement removed by JG March 11*)

(* basic definitions *)
nP=Length[lb]; predim=Min[cidim,5]; If[IntegerQ[predim],dim=predim,dim=5]; 
Jname="KFormsName"/.Options[CIPro];
Js=Table[Subscript[Jname, i],{i,1,nP}];

(* first Chern class *)
c1=lb . Js;

ch=1+Sum[c1^p/Factorial[p],{p,1,dim}]//Expand;

ch];


(* ::Subsubsection::Closed:: *)
(*ChLBSPoly: Chern character of a line bundle sum as a polynomial*)


CIPro`ChLBSPoly::usage="ChLBSPoly[ass,opt], computes the Chern character of a line bundle sum as a polynomial in basis forms.";

AssociateTo[CIPro`Private`CIProMod,"ChLBSPoly"->ChLBSPoly]; AssociateTo[CIPro`Private`CIProDep,"ChLBSPoly"->{"LBS","Conf","DimPs","AmbDim","CIDim"}];
AssociateTo[CIPro`Private`CIProInfo,"ChLBSPoly"->"Chern character of a line bundle sum, as a polynomial in basis forms."];
AppendTo[CIPro`Private`CIProSection["CIs & LineSums"],"ChLBSPoly"];

ChLBSPoly[ass_,opt___]:=Module[{lbsT,cidim,ch,i,predim,dim},

(* basic definitions *)
lbsT=Transpose[ass["LBS"]];
cidim=ass["CIDim"]; predim=Min[cidim,5]; If[IntegerQ[predim],dim=predim,dim=5]; 

(* compute Chern characters *)
ch=Sum[ChLBPoly[lbsT[[i]],dim],{i,1,Length[lbsT]}]//Expand;

ch];


(* ::Subsubsection::Closed:: *)
(*ChLBS: Chern character of a line bundle sum numerically*)


CIPro`ChLBS::usage="ChLBS[ass,opt], computes the Chern character of a line bundle sum numerically, relative to the standard basis.";

AssociateTo[CIPro`Private`CIProMod,"ChLBS"->ChLBS]; AssociateTo[CIPro`Private`CIProDep,"ChLBS"->{"LBS","Conf","DimPs","AmbDim","CIDim","Mu","ISecForm","ISec","ChLBSPoly"}];
AssociateTo[CIPro`Private`CIProInfo,"ChLBS"->"Chern character of a line bundle sum numerically, relative to the standard basis."];
AppendTo[CIPro`Private`CIProSection["CIs & LineSums"],"ChLBS"];

ChLBS[ass_,opt___]:=Module[{},

ClassConvert[ass["ChLBSPoly"],ass["ISec"],ass["CIDim"],Length[ass["Conf"]]]];


(* ::Subsubsection::Closed:: *)
(*CLBSPoly: Chern class of a line bundle sum as a polynomial*)


CIPro`CLBSPoly::usage="CLBSPoly[ass,opt], computes the Chern class of a line bundle sum as a polynomial in basis forms.";

AssociateTo[CIPro`Private`CIProMod,"CLBSPoly"->CLBSPoly]; AssociateTo[CIPro`Private`CIProDep,"CLBSPoly"->{"LBS","Conf","DimPs","AmbDim","CIDim","ChLBSPoly"}];
AssociateTo[CIPro`Private`CIProInfo,"CLBSPoly"->"Chern class of a line bundle sum, as a polynomial in basis forms."];
AppendTo[CIPro`Private`CIProSection["CIs & LineSums"],"CLBSPoly"];

CLBSPoly[ass_,opt___]:=Module[{dPs},
(*check computation can be performed*) 
dPs=ass["DimPs"];
If[!Apply[And,Map[IntegerQ,Flatten[dPs]]],ErrorPrint["Ambient space data must all be given in terms of integers to compute this keyword."];Return[$Failed];
];
(*perform computation*)
Return[Class2Class[ass["ChLBSPoly"],ass["CIDim"],First[Dimensions[ass["Conf"]]],ass["CIDim"],"Ch","C"]];]


(* ::Subsubsection::Closed:: *)
(*CLBS: Chern class of a line bundle sum numerically*)


CIPro`CLBS::usage="CLBS[ass,opt], computes the Chern class of a line bundle sum numerically, relative to the standard basis.";

AssociateTo[CIPro`Private`CIProMod,"CLBS"->CLBS]; AssociateTo[CIPro`Private`CIProDep,"CLBS"->{"LBS","Conf","DimPs","AmbDim","CIDim","Mu","ISecForm","ISec","ChLBSPoly","CLBSPoly"}];
AssociateTo[CIPro`Private`CIProInfo,"CLBS"->"Chern class of a line bundle sum numerically, relative to the standard basis."];
AppendTo[CIPro`Private`CIProSection["CIs & LineSums"],"CLBS"];

CLBS[ass_,opt___]:=Module[{},

ClassConvert[ass["CLBSPoly"],ass["ISec"],ass["CIDim"],Length[ass["Conf"]]]];


(* ::Subsubsection::Closed:: *)
(*IndLBS: Index of a line bundle sum*)


CIPro`IndLBS::usage="IndLBS[ass,opt], computes the index of a line bundle sum numerically, relative to the standard basis.";

AssociateTo[CIPro`Private`CIProMod,"IndLBS"->IndLBS]; AssociateTo[CIPro`Private`CIProDep,"IndLBS"->{"LBS","Conf","DimPs","AmbDim","CIDim","Mu","CPoly","TdPoly","ChLBSPoly"}];
AssociateTo[CIPro`Private`CIProInfo,"IndLBS"->"Index of a line bundle sum."];
AppendTo[CIPro`Private`CIProSection["CIs & LineSums"],"IndLBS"];

IndLBS[ass_,opt___]:=Module[{as,nP,dimPs,Jname,Js,tf},

(* definitions *)
dimPs=ass["DimPs"]; nP=Length[dimPs];
Jname="KFormsName"/.Options[CIPro];
Js=Table[Subscript[Jname, i],{i,1,nP}];
tf=Product[Js[[i]]^dimPs[[i]],{i,1,nP}];

(* Atiyah Singer index theorem *)
as=Expand[ass["TdPoly"]*ass["ChLBSPoly"]*ass["Mu"]];

(* extract relevant coefficient *)
Coefficient[as,tf]];


(* ::Subsection::Closed:: *)
(*Sums and tensor products of a line bundle sum*)


(* ::Subsubsection::Closed:: *)
(*LBSSum: sums of line bundle sums*)


CIPro`LBSSum::usage="LBSSum[asslist,opt], computes the sum of line bundle sums.";

AssociateTo[CIPro`Private`CIModMod,"LBSSum"->LBSSum]; AssociateTo[CIPro`Private`CIModDep,"LBSSum"->{"Conf","DimPs","LBS"}];
AssociateTo[CIPro`Private`CIModInfo,"LBSSum"->"Sum of line bundle sums."];
AppendTo[CIPro`Private`CIModSection["CIs & LineSums"],"LBSSum"];

LBSSum[ass_,opt___]:=Module[{conf,dimPs,lbsT,lbsnew},

(* options and definitions *)
conf=Map[#["Conf"]&,ass]//DeleteDuplicates; dimPs=Map[#["DimPs"]&,ass]//DeleteDuplicates;
If[Length[conf]>1 || Length[dimPs]>1,ErrorPrint["Underlying CIs are not the same."]; lbsnew={{}}];
lbsT=Map[Transpose[#["LBS"]]&,ass];

(* compute tensor product *)
lbsnew=Transpose[Flatten[lbsT,1]];
  
<|"Conf"->First[conf],"DimPs"->First[dimPs],"LBS"->lbsnew|>];


(* ::Subsubsection::Closed:: *)
(*LBSTensor: tensor product of a line bundle sum*)


CIPro`LBSTensor::usage="LBSTensor[asslist,opt], computes the tensor product of line bundle sums.";

AssociateTo[CIPro`Private`CIModMod,"LBSTensor"->LBSTensor]; AssociateTo[CIPro`Private`CIModDep,"LBSTensor"->{"Conf","DimPs","LBS"}];
AssociateTo[CIPro`Private`CIModInfo,"LBSTensor"->"Tensor power of a line bundle sums."];
AppendTo[CIPro`Private`CIModSection["CIs & LineSums"],"LBSTensor"];

LBSTensor[ass_,opt___]:=Module[{conf,dimPs,lbsT,lbsnew},

(* options and definitions *)
conf=Map[#["Conf"]&,ass]//DeleteDuplicates; dimPs=Map[#["DimPs"]&,ass]//DeleteDuplicates;
If[Length[conf]>1 || Length[dimPs]>1,ErrorPrint["Underlying CIs are not the same."]; lbsnew={{}}];
lbsT=Map[Transpose[#["LBS"]]&,ass];

(* compute tensor product *)
lbsnew=Transpose[Map[Total,Tuples[lbsT]]];
  
<|"Conf"->First[conf],"DimPs"->First[dimPs],"LBS"->lbsnew|>];


(* ::Subsubsection::Closed:: *)
(*LBSWedge: wedge product of a line bundle sum*)


CIPro`LBSWedge::usage="LBSWedge[ass,opt], computes an anti-symmetric tensro power of a line bundle sum.";

AssociateTo[CIPro`Private`CIModMod,"LBSWedge"->LBSWedge]; AssociateTo[CIPro`Private`CIModDep,"LBSWedge"->{"Conf","DimPs","LBS"}];
AssociateTo[CIPro`Private`CIModInfo,"LBSWedge"->"Wedge power of a line bundle sum. Specify power with option \"TensorPower\" (default 2)."];
AppendTo[CIPro`Private`CIModSection["CIs & LineSums"],"LBSWedge"];

LBSWedge[ass_,opt___]:=Module[{power,lbsT,nP,numline,lbsnew,ass1},

(* options and definitions *)
ass1=First[ass];
lbsT=Transpose[ass1["LBS"]];
power=Max[Round["TensorPower"/.{opt}/.Options[CIMod]],0];
nP=Length[ass1["LBS"]]; numline=Length[lbsT];

(* compute wedge power *)
If[power<=0 || power>numline,lbsnew=Table[{},{nP}],
   lbsnew=Transpose[Apply[Plus,Subsets[lbsT,{power}],1]]];

AssociateTo[ass1,"LBS"->lbsnew];
ass1];   


(* ::Subsubsection::Closed:: *)
(*LBSSymm: symmetric tensor power of a line bundle sum*)


CIPro`LBSSymm::usage="LBSSymm[ass,opt], computes a symmetric tensro power of a line bundle sum.";

AssociateTo[CIPro`Private`CIModMod,"LBSSymm"->LBSSymm]; AssociateTo[CIPro`Private`CIModDep,"LBSSymm"->{"Conf","DimPs","LBS"}];
AssociateTo[CIPro`Private`CIModInfo,"LBSSymm"->"Symmetric power of a line bundle sum. Specify power with option \"TensorPower\".(default 2)"];
AppendTo[CIPro`Private`CIModSection["CIs & LineSums"],"LBSSymm"];

LBSSymm[ass_,opt___]:=Module[{ass1,power,lbsT,nP,numline,lbsnew,lst,i},

(* options and definitions *)
ass1=First[ass];
lbsT=Transpose[ass1["LBS"]];
power=Max[Round["TensorPower"/.{opt}/.Options[CIMod]],0];
nP=Length[ass1["LBS"]]; numline=Length[lbsT];

If[power==0,lbsnew=Table[{},{nP}],
 lst=DeleteDuplicates[Map[Sort,Tuples[Table[{i},{i,1,numline}],power]]];
 lbsnew=Transpose[Apply[Plus,Map[Extract[lbsT,#]&,lst],1]]]; 

AssociateTo[ass1,"LBS"->lbsnew];
ass1];       


(* ::Subsection::Closed:: *)
(*Associations with line bundle cohomology info*)


(* ::Subsubsection::Closed:: *)
(*CohList: specify q in H^q *)


CIPro`CohList::usage="CohList[ass,opt], adds cohomology type q={\!\(\*SubscriptBox[\(q\), \(\[Placeholder]\)]\),...,\!\(\*SubscriptBox[\(q\), \(r\)]\)} in \!\(\*SuperscriptBox[\(H\), SubscriptBox[\(q\), \(i\)]]\)(\!\(\*SubscriptBox[\(L\), \(i\)]\)) to association.";

AssociateTo[CIPro`Private`CIProMod,"CohList"->CohList]; AssociateTo[CIPro`Private`CIProDep,"CohList"->{"LBS","Conf","DimPs","AmbDim","CIDim","AmbCoords"}];
AssociateTo[CIPro`Private`CIProInfo,"CohList"->"Adds cohomology type q={\!\(\*SubscriptBox[\(q\), \(\[Placeholder]\)]\),...,\!\(\*SubscriptBox[\(q\), \(r\)]\)} in \!\(\*SuperscriptBox[\(H\), SubscriptBox[\(q\), \(i\)]]\)(\!\(\*SubscriptBox[\(L\), \(i\)]\)) to association."];
AppendTo[CIPro`Private`CIProSection["CIs & LineSums"],"CohList"];

CohList[ass_,opt___]:=Module[{q,qv,rk},

q="CohQ"/.{opt}/.Options[CIProp]; 
rk=Length[Transpose[ass["LBS"]]];

If[IntegerQ[q],qv=Table[q,{rk}],qv=q];

qv];


(* ::Subsubsection::Closed:: *)
(*Basis: generate basis for ambient space cohomology*)


CIPro`Basis::usage="Basis[ass,opt], generates basis for ambient space cohomology.";

AssociateTo[CIPro`Private`CIProMod,"Basis"->Basis]; AssociateTo[CIPro`Private`CIProDep,"Basis"->{"LBS","Conf","DimPs","AmbDim","CIDim","AmbCoords","CohList"}];
AssociateTo[CIPro`Private`CIProInfo,"Basis"->"Generates basis for ambient space cohomology."];
AppendTo[CIPro`Private`CIProSection["CIs & LineSums"],"Basis"];

Basis[ass_,opt___]:=Module[{lT,n,qv,coords,rk,i,monbas},

(* basis defitions *)
lT=Transpose[ass["LBS"]]; n=ass["DimPs"];
qv=ass["CohList"]; coords=ass["AmbCoords"];
rk=Length[lT];

monbas=Table[CIPro`Private`CreateBBWBasis[n,lT[[i]],qv[[i]],coords],{i,1,rk}];

monbas];


(* ::Subsubsection::Closed:: *)
(*AmbCohDim: dimension of ambient space cohomology*)


CIPro`AmbCohDim::usage="AmbCohDim[ass,opt], adds the ambient space cohomology dimension to association.";

AssociateTo[CIPro`Private`CIProMod,"AmbCohDim"->AmbCohDim]; AssociateTo[CIPro`Private`CIProDep,"AmbCohDim"->{"LBS","Conf","DimPs","AmbDim","CIDim","AmbCoords","CohList","Basis"}];
AssociateTo[CIPro`Private`CIProInfo,"AmbCohDim"->"Adds the ambient space cohomology dimension to association."];
AppendTo[CIPro`Private`CIProSection["CIs & LineSums"],"AmbCohDim"];

AmbCohDim[ass_,opt___]:=Module[{dims,dim},

dims=Map[Length,ass["Basis"]];dim=Total[dims];

dim];


(* ::Subsubsection::Closed:: *)
(*Coset: add matrices for the trivial coset which describes ambient space cohomology*)


CIPro`Coset::usage="Coset[ass,opt], adds matrices for the trivial coset which describes ambient space cohomology.";

AssociateTo[CIPro`Private`CIProMod,"Coset"->Coset]; AssociateTo[CIPro`Private`CIProDep,"Coset"->{"LBS","Conf","DimPs","AmbDim","CIDim","AmbCoords","CohList","Basis","AmbCohDim"}];
AssociateTo[CIPro`Private`CIProInfo,"Coset"->"Adds matrices for the trivial coset which describes ambient space cohomology."];
AppendTo[CIPro`Private`CIProSection["CIs & LineSums"],"Coset"];

Coset[ass_,opt___]:=Module[{a,b,dim},

dim=ass["AmbCohDim"];
If[dim>0,a=IdentityMatrix[dim];b=Table[{0},{dim}],a={};b={}];

{a,b}];


(* ::Subsubsection::Closed:: *)
(*CohInfo: add info about cohomology*)


CIPro`CohInfo::usage="CohInfo[ass,opt], adds info about cohomology.";

AssociateTo[CIPro`Private`CIProMod,"CohInfo"->CohInfo]; AssociateTo[CIPro`Private`CIProDep,"CohInfo"->{"LBS","Conf","DimPs","AmbDim","CIDim","AmbCoords","CohList","Basis","AmbCohDim","Coset"}];
AssociateTo[CIPro`Private`CIProInfo,"CohInfo"->"Adds info about cohomology."];
AppendTo[CIPro`Private`CIProSection["CIs & LineSums"],"CohInfo"];

CohInfo[ass_,opt___]:=Module[{cohinfo},

cohinfo="CohInfo"/.{opt}/.Options[CIProp];

cohinfo];


(* ::Subsubsection::Closed:: *)
(*LBSCohDim: adds dimension of line bundle sum cohomology*)


CIPro`LBSCohDim::usage="LBSCohDim[ass,opt], adds dimension of line bundle sum cohomology.";

AssociateTo[CIPro`Private`CIProMod,"LBSCohDim"->LBSCohDim]; AssociateTo[CIPro`Private`CIProDep,"LBSCohDim"->{"LBS","Conf","DimPs","AmbDim","CIDim","AmbCoords","CohList","Basis","AmbCohDim","Coset","CohInfo"}];
AssociateTo[CIPro`Private`CIProInfo,"LBSCohDim"->"Adds dimension of line bundle sum cohomology."];
AppendTo[CIPro`Private`CIProSection["CIs & LineSums"],"LBSCohDim"];

LBSCohDim[ass_,opt___]:=Module[{a,b,mod,lbscohdim},

mod="Modulus"/.{opt}/.Options[CIProp];
{a,b}=ass["Coset"];
If[a==={} || b==={},lbscohdim=0,
  lbscohdim=MatrixRank[a,Modulus->mod]-MatrixRank[b,Modulus->mod]];

lbscohdim];


(* ::Subsection::Closed:: *)
(*Line bundle cohomology*)


(* ::Subsubsection::Closed:: *)
(*MapLBS: construct map between two line bundle sums*)


CIPro`MapLBS::usage="MapLBS[asspair,opt], computes random map between two line bundle sums. NOTE: Any effective but not semi-positive map element is automatically set to zero.";

AssociateTo[CIPro`Private`CIModMod,"MapLBS"->MapLBS]; AssociateTo[CIPro`Private`CIModDep,"MapLBS"->{"Conf","DimPs","AmbCoords","LBS"}];
AssociateTo[CIPro`Private`CIModInfo,"MapLBS"->"Computes random map between two line bundle sums. NOTE: Any effective but not semi-positive map element is automatically set to zero."];
AppendTo[CIPro`Private`CIModSection["CIs & LineSums"],"MapLBS"];

MapLBS[asspair_,opt___]:=Module[{assin,assout,coords,lbsinT,lbsoutT,map,i,j},

{assin,assout}=asspair;
coords=assin["AmbCoords"];
lbsinT=Transpose[assin["LBS"]]; lbsoutT=Transpose[assout["LBS"]];

If[!Apply[And,Map[IntegerQ,Flatten[{lbsinT,lbsoutT}]]],ErrorPrint["All line bundle and ambient space data must be given in terms of integers to compute this keyword."];Return[$Failed];
];

map=Table[RandomPoly[lbsoutT[[i]]-lbsinT[[j]],coords,opt],{i,1,Length[lbsoutT]},{j,1,Length[lbsinT]}];

map];


(* ::Subsubsection::Closed:: *)
(*MapSpaceLBS: constructs Ker, Im or Coker of map between two line bundle sum cohomologies*)


CIPro`MapSpaceLBS::usage="MapSpaceLBS[asspair,opt], constructs Ker, Im or Coker of map between two line bundle sum cohomologies. NOTE: Any effective but not semi-positive map element is automatically set to zero.";

AssociateTo[CIPro`Private`CIModMod,"MapSpaceLBS"->MapSpaceLBS]; AssociateTo[CIPro`Private`CIModDep,"MapSpaceLBS"->{"Conf","DimPs","AmbCoords","LBS","AmbDim","CIDim","AmbCoords","CohList","Basis","AmbCohDim","Coset","CohInfo"}];
AssociateTo[CIPro`Private`CIModInfo,"MapSpaceLBS"->"Constructs Ker, Im or Coker of map between two line bundle sum cohomologies. NOTE: Any effective but not semi-positive map element is automatically set to zero."];
AppendTo[CIPro`Private`CIModSection["CIs & LineSums"],"MapSpaceLBS"];

MapSpaceLBS[asspair_,opt___]:=Module[
  {space,map,assin,assout,bbwin,bbwout,bbwres,assres,conf,ambcohdim,cidim,ambdim},


(* options *)
space="Space"/.{opt}/.Options[CIMod];
map="Map"/.{opt}/.Options[CIMod];
If[map===Automatic,map=MapLBS[asspair,opt]];
{assin,assout}=asspair;

(* create BBW lists *)


bbwin={"CoordNum"->assin["DimPs"],"CoordNames"->assin["AmbCoords"],"LineSum"->assin["LBS"],
       "CohList"->assin["CohList"], "AmbDim"->assin["AmbCohDim"],"Basis"->assin["Basis"],
       "Coset"->assin["Coset"],"Dim"->assin["LBSCohDim"],"CohInfo"->assin["CohInfo"]};
       
bbwout={"CoordNum"->assout["DimPs"],"CoordNames"->assout["AmbCoords"],"LineSum"->assout["LBS"],
       "CohList"->assout["CohList"], "AmbDim"->assout["AmbCohDim"],"Basis"->assout["Basis"],
       "Coset"->assout["Coset"],"Dim"->assout["LBSCohDim"],"CohInfo"->assout["CohInfo"]};      

bbwres=CIPro`Private`MapBBWList[bbwin,bbwout,map,opt,"OutFormat"->space]; (*optional argument added JG march 11th*)

{conf,ambdim,ambcohdim,cidim}=Switch[space,"Ker",{assin["Conf"],assin["AmbDim"],assin["AmbCohDim"],assin["CIDim"]},
                                    "Im",{assout["Conf"],assout["AmbDim"],assout["AmbCohDim"],assout["CIDim"]},
                                    "Coker",{assout["Conf"],assout["AmbDim"],assout["AmbCohDim"],assout["CIDim"]}];

assres=<|"DimPs"->("CoordNum"/.bbwres),"Conf"->conf,"AmbDim"->ambdim,"AmbCohDim"->ambcohdim,"CIDim"->cidim,"LBS"->("LineSum"/.bbwres),"AmbCoords"->("CoordNames"/.bbwres),
         "AmbCohDim"->("AmbDim"/.bbwres),"CohList"->("CohList"/.bbwres),"Basis"->("Basis"/.bbwres),
         "Coset"->("Coset"/.bbwres),"LBSCohDim"->("Dim"/.bbwres),"CohInfo"->("CohInfo"/.bbwres)|>;

assres];


(* ::Subsubsection::Closed:: *)
(*QuotientLBS: form a quotient of two line bundle cohomologies*)


CIPro`QuotientLBS::usage="QuotientLBS[asspair,opt], forms a quotient of two line bundle cohomologies.";

AssociateTo[CIPro`Private`CIModMod,"QuotientLBS"->QuotientLBS]; AssociateTo[CIPro`Private`CIModDep,"QuotientLBS"->{"Conf","DimPs","AmbCoords","LBS","AmbDim","CIDim","AmbCoords","CohList","Basis","AmbCohDim","Coset","CohInfo"}];
AssociateTo[CIPro`Private`CIModInfo,"QuotientLBS"->"Forms a quotient of two line bundle cohomologies."];
AppendTo[CIPro`Private`CIModSection["CIs & LineSums"],"QuotientLBS"];

QuotientLBS[asspair_,opt___]:=Module[{assin,assout,bbwin,bbwout,bbwres,assres},

{assin,assout}=asspair;

(* create BBW lists *)

bbwin={"CoordNum"->assin["DimPs"],"CoordNames"->assin["AmbCoords"],"LineSum"->assin["LBS"],
       "CohList"->assin["CohList"], "AmbDim"->assin["AmbCohDim"],"Basis"->assin["Basis"],
       "Coset"->assin["Coset"],"Dim"->assin["LBSCohDim"],"CohInfo"->assin["CohInfo"]};
bbwout={"CoordNum"->assout["DimPs"],"CoordNames"->assout["AmbCoords"],"LineSum"->assout["LBS"],
       "CohList"->assout["CohList"], "AmbDim"->assout["AmbCohDim"],"Basis"->assout["Basis"],
       "Coset"->assout["Coset"],"Dim"->assout["LBSCohDim"],"CohInfo"->assout["CohInfo"]};   

bbwres=CIPro`Private`QuotientBBW[bbwin,bbwout,opt];

assres=<|"DimPs"->("CoordNum"/.bbwres),"LBS"->("LineSum"/.bbwres),"AmbCoords"->("CoordNames"/.bbwres),
         "AmbCohdim"->("AmbDim"/.bbwres),"CohList"->("CohList"/.bbwres),"Basis"->("Basis"/.bbwres),
         "Coset"->("Coset"/.bbwres),"LBSCohDim"->("Dim"/.bbwres),"CohInfo"->("CohInfo"/.bbwres)|>;

assres];


(* ::Subsubsection::Closed:: *)
(*DirectSumLBS: calculate the direct sum of  line bundle sum cohomologies*)


CIPro`DirectSumLBS::usage="DirectSumBS[asslst,opt], calculates the direct sum of line bundle sum cohomologies.";

AssociateTo[CIPro`Private`CIModMod,"DirectSumLBS"->DirectSumLBS]; AssociateTo[CIPro`Private`CIModDep,"DirectSumLBS"->{"Conf","DimPs","AmbCoords","LBS","AmbDim","CIDim","AmbCoords","CohList","Basis","AmbCohDim","Coset","CohInfo"}];
AssociateTo[CIPro`Private`CIModInfo,"DirectSumLBS"->"Calculates the direct sum of line bundle sum cohomologies."];
AppendTo[CIPro`Private`CIModSection["CIs & LineSums"],"DirectSumLBS"];

DirectSumLBS[asslst_,opt___]:=Module[{bbwlst,i,bbwres,assres},

bbwlst={};
For[i=1,i<=Length[asslst],i++,
 bbwlst=Append[bbwlst,{"CoordNum"->asslst[[i]]["DimPs"],"CoordNames"->asslst[[i]]["AmbCoords"],"LineSum"->asslst[[i]]["LBS"],
       "CohList"->asslst[[i]]["CohList"], "AmbDim"->asslst[[i]]["AmbCohDim"],"Basis"->asslst[[i]]["Basis"],
       "Coset"->asslst[[i]]["Coset"],"Dim"->asslst[[i]]["LBSCohDim"],"CohInfo"->asslst[[i]]["CohInfo"]}];
];

bbwres=CIPro`Private`DirectSumBBW[bbwlst,opt];

assres=<|"DimPs"->("CoordNum"/.bbwres),"LBS"->("LineSum"/.bbwres),"AmbCoords"->("CoordNames"/.bbwres),
         "AmbCohdim"->("AmbDim"/.bbwres),"CohList"->("CohList"/.bbwres),"Basis"->("Basis"/.bbwres),
         "Coset"->("Coset"/.bbwres),"LBSCohDim"->("Dim"/.bbwres),"CohInfo"->("CohInfo"/.bbwres)|>;

assres];


(* ::Subsubsection::Closed:: *)
(*KoszulLBS: calculates map in the spectral sequence associated to the Koszul  complex*)


CIPro`KoszulLBS::usage="KoszulLBS[asspair,opt], calculates map in the spectral sequence associated to Koszul comples.";

AssociateTo[CIPro`Private`CIModMod,"KoszulLBS"->KoszulLBS]; AssociateTo[CIPro`Private`CIModDep,"KoszulLBS"->{"Conf","DimPs","AmbCoords","LBS","DefEqs"}];
AssociateTo[CIPro`Private`CIModInfo,"KoszulLBS"->"Calculates map in the spectral sequence associated to Koszul complex."];
AppendTo[CIPro`Private`CIModSection["CIs & LineSums"],"KoszulLBS"];

KoszulLBS[assin_,opt___]:=Module[{ass,k,p,q,res,lb,nb,coords,plst,n},

(* options *)
ass=First[assin];
{k,p,q}="Ekpq"/.{opt}/.Options[CIMod];
n=ass["DimPs"]; lb=First[Transpose[ass["LBS"]]];
nb=ass["Conf"]; coords=ass["AmbCoords"];
plst=ass["DefEqs"];

res=CIPro`Private`KoszulMap[n,lb,nb,p,q,k,coords,plst,opt];

res];


(* ::Subsubsection::Closed:: *)
(*CohLBS: compute cohomology of a line bundle sum*)


CIPro`CohLBS::usage="CohLBS[ass,opt], computes the cohomology of a line bundle sum.";

AssociateTo[CIPro`Private`CIModMod,"CohLBS"->CohLBS]; AssociateTo[CIPro`Private`CIModDep,"CohLBS"->{"LBS","Conf","DimPs","AmbDim","CIDim","AmbCoords","MonList","DefEqs"}];
AssociateTo[CIPro`Private`CIModInfo,"CohLBS"->"Cohomology of a line bundle."];
AppendTo[CIPro`Private`CIModSection["CIs & LineSums"],"CohLBS"];

CohLBS[assin_,opt___]:=Module[{ass,prot,coh,nlbs,ncoh,format,cohdim,q,a,newcoh,cohq,h,hass,
  asslst,asslst0,assout,cohsum,coh0},

(* options and basic definitions *)
prot="CohProt"/.{opt}/.Options[CIMod];
format="CohFormat"/.{opt}/.Options[CIMod];
cohsum="CohSum"/.{opt}/.Options[CIMod];
ass=First[assin]; 

(*error print if necessary*)
If[(!Apply[And,Map[IntegerQ,Flatten[ass["LBS"]]]]),ErrorPrint["All line bundle sum data must be given in terms of integers to compute this keyword."];Return[$Failed];
];

(* compute cohomology using BBW modules *)
coh0=CIPro`Private`CohLinesBBW[ass["LBS"],ass["DimPs"],ass["Conf"],ass["AmbCoords"],ass["DefEqs"],"CohProt"->prot,opt];
If[cohsum,coh=Map[List[CIPro`Private`DirectSumBBW[#]]&,coh0],coh=coh0];
{ncoh,nlbs}=Most[Dimensions[coh]];
cohdim="Dim"/.coh;

(* re=package result *)
asslst={};
For[q=1,q<=ncoh,q++,
  asslst0={};
  For[a=1,a<=nlbs,a++,
    h=coh[[q,a]]; assout=KeyDrop[ass,{(*"MonList",*)"LBS"}];(*PUT MONLIST BACK IN JG MARCH 10TH*)
    AssociateTo[assout,{"LBS"->("LineSum"/.h),"AmbCohDim"->("AmbDim"/.h),"Basis"->("Basis"/.h),
                       "Coset"->("Coset"/.h),"CohInfo"->("CohInfo"/.h),"CohList"->("CohList"/.h),
                       "LBSCohDim"->("Dim"/.h)}];
    asslst0=Append[asslst0,assout];
  ];
  asslst=Append[asslst,asslst0];
];  

If[format==="Dim",Return[cohdim],Return[asslst]];
];


(* ::Subsection::Closed:: *)
(*BBW modules from CICY package*)


(* ::Subsubsection::Closed:: *)
(* CreateBBWBasis: Generate rational function basis for line bundle cohomology*)


CIPro`Private`CreateBBWBasis[n_,k_,q_,coords_]:=Module[{cnames,nP,pow,mon,i,X},

(* options *)
nP=Length[n];

(* if any entry falls into the Bott gap return empty list *)
If[Apply[Or,Table[k[[i]]<0 && k[[i]]>=-n[[i]],{i,1,nP}]],Return[{}]];

(* if cohomology doesn't match given one return empty list *)
If[Total[Pick[n,k,X_/;X<0]]!=q,Return[{}]];

(* compute polynomials powers for each projective factor *)
pow=Table[Switch[k[[i]]>=0,True,Combinatorica`Compositions[k[[i]],n[[i]]+1]//Reverse,
                          False,-Combinatorica`Compositions[-k[[i]]-n[[i]]-1,n[[i]]+1]-1],{i,1,nP}];

(* compute monomial lists for each projective factor *)
mon=Table[Map[Apply[Times,Power[coords[[i]],#]]&,pow[[i]]],{i,1,nP}];


Map[Apply[Times,#]&,Tuples[mon]]];



(* ::Subsubsection::Closed:: *)
(* CreateBBWList: Create a list representing a BBW representation of line bundle cohomology*)


Options[CIPro`Private`CreateBBWList]={"CohInfo"->{}};

CIPro`Private`CreateBBWList[n_,lbs_,q_,coords_,opt___]:=Module[{lT,rk,nP,qv,monbas,dims,dim,i,a,b,cohinfo},

(* basic definitions *)
nP=Length[n]; lT=Transpose[lbs];rk=Length[lT];
If[IntegerQ[q],qv=Table[q,{rk}],qv=q];
cohinfo="CohInfo"/.{opt}/.Options[CIPro`Private`CreateBBWList];
If[cohinfo=={},cohinfo=Table[Null,{rk}]];

(* compute rational basis *)
monbas=Table[CIPro`Private`CreateBBWBasis[n,lT[[i]],qv[[i]],coords],{i,1,rk}];
dims=Map[Length,monbas];dim=Total[dims];

(* define matrices for trivial coset *)
If[dim>0,a=IdentityMatrix[dim];b=Table[{0},{dim}],a={};b={}];

(* return list *)
{"CoordNum"->n,"CoordNames"->coords,"LineSum"->lbs,"CohList"->qv,"AmbDim"->dim,"Basis"->monbas,"Coset"->{a,b},"Dim"->dim,"CohInfo"->cohinfo}];


(* ::Subsubsection::Closed:: *)
(* MapBBWList: Create a BBW list representing the Ker, Im or Coker of a map between BBW lists*)


Options[CIPro`Private`MapBBWList]={"OutFormat"->"Ker","CicyMeth"->"Check",Modulus->0,"Numerical"->False,Tolerance->10^(-8),"Meth"->"expand"};

CIPro`Private`MapBBWList[lin_,lout_,map_,opt___]:=Module[{outform,meth,din,dout,inbasis,outbasis,i,j,k,l,n,m,coords,inbv,outv,trim,X,Y,
trim1,inambdim,outambdim,a,b,at,bt,mod,rkat,maat,rkmaat,kercond,ap,bp,res,dim,ns,btma,nslen,ma,linein,lineout,pc,d,
creplpos,crepl1,pos,neg,creplneg,crepl,rem,dimPs,coordsrepl,coordsinv,coordsto0,rkbt,mbbt,rkmbbt,mabt,mta,dma,numer,toler,meth1},

(* options and definitions *)
outform="OutFormat"/.{opt}/.Options[CIPro`Private`MapBBWList];
meth="CicyMeth"/.{opt}/.Options[CIPro`Private`MapBBWList];
meth1="Meth"/.{opt}/.Options[CIPro`Private`MapBBWList];
mod=Modulus/.{opt}/.Options[CIPro`Private`MapBBWList];
numer="Numerical"/.{opt}/.Options[CIPro`Private`MapBBWList];
If[numer,toler=Tolerance/.{opt}/.Options[CIPro`Private`MapBBWList];mod=0,toler=0];
coords="CoordNames"/.lin;
dimPs="CoordNum"/.lin;
inbasis="Basis"/.lin; outbasis="Basis"/.lout;
inambdim="AmbDim"/.lin;outambdim="AmbDim"/.lout;
linein=Transpose["LineSum"/.lin]; lineout=Transpose["LineSum"/.lout];
{dout,din}=Dimensions[map];


coordsinv=Table[Switch[lineout[[i,j]]<0,True,coords[[j,k+1]]-> 1/coords[[j,k+1]],False,1->1],{i,1,Length[lineout]},{j,1,Length[dimPs]},{k,0,dimPs[[j]]}];
coordsto0=Flatten[Table[{1/coords[[i,j+1]]->0,coords[[i,j+1]]^(n_/;n<0)->0},{i,1,Length[dimPs]},{j,0,dimPs[[i]]}]];

(* compute matrix associated to polynomial map *)
(* Print["Begin matrix extraction!"]; *)
If[inambdim == 0 || outambdim == 0,m={{}}];
If[inambdim > 0 && outambdim > 0,
(* compute source space basis vectors and multiply by map *)
inbv=Transpose[Flatten[Table[Map[Times[#,IdentityMatrix[din][[i]]]&,inbasis[[i]]],{i,1,din}],1]];
If[meth1=="expand",
outv=Expand[map . inbv]; 
outv=Table[outv[[i]]/.Flatten[coordsinv[[i]]],{i,1,Length[outv]}];
outv=outv/.coordsto0;
m=Apply[Join,Table[Transpose[Map[CIPro`Private`newcoeff[#,(outbasis[[i]]/.Flatten[coordsinv[[i]]])]&,outv[[i]]]],{i,1,Length[outbasis]}]]];
If[meth1=!="expand",
outv=map . inbv;
m=Apply[Join,Table[Transpose[Map[CIPro`Private`newcoeff[#,outbasis[[i]]]&,outv[[i]]]],{i,1,Length[outbasis]}]]
]
];

(* store the matrices defining in and out spaces *)
{a,b}="Coset"/.lin;{at,bt}="Coset"/.lout;
If[numer,{a,b}={a,b}//N;{at,bt}={at,bt}//N;m=m//N];

(* if requested, check if map is consistent with subspaces *)
If[meth=="Check" && m!={{}},
  If[numer,rkat=MatrixRank[at,Tolerance->toler,ZeroTest->(Abs[#]<=toler&)];
  rkbt=MatrixRank[bt,Tolerance->toler,ZeroTest->(Abs[#]<=toler&)],
  rkat=MatrixRank[at,Modulus->mod];rkbt=MatrixRank[bt,Modulus->mod]];
  maat=Join[Transpose[m . a],Transpose[at]];
  If[numer,rkmaat=MatrixRank[maat,Tolerance->toler,ZeroTest->(Abs[#]<=toler&)],rkmaat=MatrixRank[maat,Modulus->mod]];
  If[rkat!=rkmaat,Message[CIPro::"map error","Im"]];
  mbbt=Join[Transpose[m . b],Transpose[bt]];
  If[numer,rkmbbt=MatrixRank[mbbt,Tolerance->toler,ZeroTest->(Abs[#]<=toler&)],rkmbbt=MatrixRank[mbbt,Modulus->mod]];
  If[rkbt != rkmbbt,Message[CIPro::"map error","Ker"]]];

(* if requested return representing matrix *)
If[outform=="Map",Return[m]];

(* if requested compute create BBW list for Ker of map *)
If[outform=="Ker",
If[m=={{}},ap=a;bp=b;dim="Dim"/.lin,
  mta=m . a; dma=Dimensions[mta][[2]];
  mabt=Join[Transpose[m . a],Transpose[bt]]//Transpose;
  If[numer,ns=NullSpace[mabt,Tolerance->toler,ZeroTest->(Abs[#]<=toler&)],ns=NullSpace[mabt,Modulus->mod]];
  ns=Map[Take[#,dma]&,ns];
  If[ns=={},ap=Table[{0},{"AmbDim"/.lin}];bp=ap;dim=0, 
    ns=Transpose[ns];
    ap=a . ns;bp=b;
    If[numer,dim=MatrixRank[ap,Tolerance->toler,ZeroTest->(Abs[#]<=toler&)]
        -MatrixRank[bp,Tolerance->toler,ZeroTest->(Abs[#]<=toler&)],
        dim=MatrixRank[ap,Modulus->mod]-MatrixRank[bp,Modulus->mod]]]];
  res={"CoordNum"->("CoordNum"/.lin),"CoordNames"->("CoordNames"/.lin),"LineSum"->("LineSum"/.lin),"CohList"->("CohList"/.lin),"AmbDim"->("AmbDim"/.lin),
     "Basis"->("Basis"/.lin),"Coset"->{ap,bp},"Dim"->dim,"CohInfo"->("CohInfo"/.lin)};
Return[res]];
     
(* if requested compute create BBW list for Im of map *)
If[outform=="Im",
 If[m!={{}},
    ma=m . a; d="AmbDim"/.lout;
    btma=Transpose[Join[Transpose[bt],Transpose[ma]]]; nslen=Dimensions[bt][[2]];
    If[numer,ns=NullSpace[btma,Tolerance->toler,ZeroTest->(Abs[#]<=toler&)],
             ns=NullSpace[btma,Modulus->mod]];
    If[ns=={},ns=Table[{0},{nslen}],ns=Transpose[Map[Take[#,nslen]&,ns]]];
    ap=CIPro`Private`CR[ma,mod,toler,numer]; bp=CIPro`Private`CR[bt . ns,mod,toler,numer]; 
    If[numer,dim=MatrixRank[ap,Tolerance->toler,ZeroTest->(Abs[#]<=toler&)]
        -MatrixRank[bp,Tolerance->toler,ZeroTest->(Abs[#]<=toler&)],
        dim=MatrixRank[ap,Modulus->mod]-MatrixRank[bp,Modulus->mod]],
    ap={};bp={};dim=0];
  res={"CoordNum"->("CoordNum"/.lout),"CoordNames"->("CoordNames"/.lout),"LineSum"->("LineSum"/.lout),"CohList"->("CohList"/.lout),
       "AmbDim"->("AmbDim"/.lout),"Basis"->("Basis"/.lout),"Coset"->{ap,bp},"Dim"->dim,"CohInfo"->("CohInfo"/.lout)};
  Return[res]];

(* if requested compute create BBW list for Coker of map *)
If[outform=="Coker",
   ap=at; d="AmbDim"/.lout;
   If[m!={{}},bp=Join[Transpose[m . a],Transpose[bt]]//Transpose;
   bp=CIPro`Private`CR[bp,mod,toler,numer];
   If[numer,dim=MatrixRank[ap,Tolerance->toler,ZeroTest->(Abs[#]<=toler&)]
       -MatrixRank[bp,Tolerance->toler,ZeroTest->(Abs[#]<=toler&)],
       dim=MatrixRank[ap,Modulus->mod]-MatrixRank[bp,Modulus->mod]],
   bp=bt;dim="Dim"/.lout];
   res={"CoordNum"->("CoordNum"/.lout),"CoordNames"->("CoordNames"/.lout),"LineSum"->("LineSum"/.lout),"CohList"->("CohList"/.lout),
       "AmbDim"->("AmbDim"/.lout),"Basis"->("Basis"/.lout),"Coset"->{ap,bp},"Dim"->dim,"CohInfo"->("CohInfo"/.lout)};
  Return[res]];
    
];

(* simplify matrix by col reduction *)
CIPro`Private`CR[m_,mod_,toler_,numer_]:=Module[{nc,mr,zv},
nc=Dimensions[m][[1]]; zv=Table[0,{nc}];
If[numer,mr=DeleteCases[RowReduce[Transpose[m],Tolerance->toler,ZeroTest->(Abs[#]<=toler&)],zv],
         mr=DeleteCases[RowReduce[Transpose[m],Modulus->mod],zv]];
If[mr=={},mr={zv}];
Transpose[mr]];

(* fix coefficient function to deal with constant basis element *)
CIPro`Private`newcoeff[expr_,basis_]:=Module[{},
If[basis==={1},Return[{expr}],Return[Coefficient[expr,basis]]]];


(* ::Subsubsection:: *)
(* QuotientBBW: Form a quotient of two BBW lists*)


CIPro`Private`QuotientBBW[l1_List,l2_List,opt___]:=Module[{linesum,rk,map,res},
linesum="LineSum"/.l1;
rk=Length[Transpose[linesum]];
map=IdentityMatrix[rk];
res=CIPro`Private`MapBBWList[l2,l1,map,"OutFormat"->"Coker","CicyMeth"->"nocheck",opt];
res];


(* ::Subsubsection::Closed:: *)
(* DirectSumBBW: Takes the direct sum of BBW lists*)


Options[CIPro`Private`DirectSumBBW]={"CicyMeth"->"NoCount"};

CIPro`Private`DirectSumBBW[llst_List,opt___]:=Module[{dims,lpick,d,coordnum,coordnames,linesum,cohlist,ambdim,basis,dim,A,B,cohinfo,i,llstc,X,cicymeth},

(* options *)
cicymeth="CicyMeth"/.{opt}/.Options[CIPro`Private`DirectSumBBW];

(* insert counter into CohInfo *)
llstc=llst;
If[cicymeth==="Count",
For[i=1,i<=Length[llstc],i++,
  cohinfo=Replace["CohInfo"/.llstc[[i]],X_->{i,X},{1}]/.{X_,Null}->X;
  llstc[[i]]=Append[DeleteCases[llstc[[i]],"CohInfo"->__],"CohInfo"->cohinfo]]];  

(* remove all zero-dim. lists and deal with special cases *)
If[Length[llstc]==1,Return[llstc[[1]]]];
dims="Dim"/.llstc;
lpick=Pick[llstc,dims,d_/;d>0];
If[Length[lpick]==0,Return[First[llstc]]];
If[Length[lpick]==1,Return[First[lpick]]];

(* combine non-trivial lists *)
coordnum="CoordNum"/.First[lpick];
coordnames="CoordNames"/.First[lpick];
linesum=Apply[Join,Map[Transpose,"LineSum"/.lpick]]//Transpose;
cohlist=Apply[Join,"CohList"/.lpick];
ambdim=Total["AmbDim"/.lpick];
basis=Apply[Join,"Basis"/.lpick];
dim=Total["Dim"/.lpick];
A=BlockMatrix[Map[First,"Coset"/.lpick]];
B=BlockMatrix[Map[Last,"Coset"/.lpick]];
cohinfo=Apply[Join,"CohInfo"/.lpick];

{"CoordNum"->coordnum,"CoordNames"->coordnames,"LineSum"->linesum,"CohList"->cohlist,"AmbDim"->ambdim,"Basis"->basis,
 "Coset"->{A,B},"Dim"->dim,"CohInfo"->cohinfo}];


(* ::Subsubsection::Closed:: *)
(* KoszulMap: Create a map in the spectral sequence of a Kozsul resolution*)


Options[CIPro`Private`KoszulMap]={};

CIPro`Private`KoszulMap[n_,lb_List,nb_List,p_Integer,q_Integer,k_Integer,coords_,plst_,opt___]:=Module[{nP,linmap,symmnum,cicynum,nbT,
 coeffsize,Qlst,Plst,Alst,Blst,K,map,Alen,Blen,A,B,i,irrset,Aset,Bset,AcB,sgn,Pind,ones,monlst,pstr2,pstr,
 ddet,j,kk,ll,lc,irrcoords,a,b,indp,indl,ps,lcn,sums,prod,X,Y,res,Aind,onelst,zerolst,lonelst,lzerolst,dirr,lAcB,S,
 prefac,Ione,l,IS,sumseq,facprod,lcprod,pol,\[Epsilon],AcBspec,AcBcont,Scont,m,mapent},

(* options and basic definitions *)
nbT=Transpose[nb];
nP=Length[n];K=Length[Transpose[nb]];
Aind=Table[i,{i,1,nP}]; Pind=Table[i,{i,1,K}];

(* compute in and out line bundle sums and corresponding index sets *)
Qlst=LineTensor[LineWedge[-nb,p],Transpose[{lb}]]//Transpose;
Plst=LineTensor[LineWedge[-nb,p-k],Transpose[{lb}]]//Transpose;
Alst=Subsets[Table[i,{i,1,K}],{p}]; Alen=Length[Alst];
Blst=Subsets[Table[i,{i,1,K}],{p-k}]; Blen=Length[Blst];

(* construct map *)
map=Table[0,{Blen},{Alen}];
For[B=1,B<=Blen,B++,
 For[A=1,A<=Alen,A++,
 (* check if set A is contained in set B, otherwise map component is zero *)
 Aset=Alst[[A]]; Bset=Blst[[B]];AcB=Complement[Aset,Bset];
 If[(Length[AcB]+Length[Bset])>Length[Aset],map[[B,A]]=0,
 (* first find set of irregular Ps *)
 irrset=Select[Aind,Qlst[[A,#]]<0 && Plst[[B,#]]>=0&];
 (* find sign of map *)  
 sgn=Signature[Join[Bset,AcB]];
 (* deal with case where all directions are regular *)
 If[Length[irrset]==0,map[[B,A]]=sgn*Product[plst[[AcB[[i]]]],{i,1,Length[AcB]}],
 (* deal with case where some directions are irregular *)
  onelst=Table[Select[AcB,nb[[irrset[[i]],#]]==1&],{i,1,Length[irrset]}]; lonelst=Map[Length,onelst];
  zerolst=Table[Select[AcB,nb[[irrset[[i]],#]]==0&],{i,1,Length[irrset]}]; lzerolst=Map[Length,zerolst];
  dirr=n[[irrset]]+1;lAcB=Table[Length[AcB],{Length[irrset]}];
  (* check if conditions for non-zero map are satsified... *)
  If[lonelst==dirr && (lonelst+lzerolst)==lAcB,
  (* ...and compute map if they are, first determine contributing directions for each polynomial *)
  S=Table[Select[irrset,nb[[#,AcB[[i]]]]==1&],{i,1,Length[AcB]}];
  (* split up into contributing and spectator polynomials *)
  AcBspec=Pick[AcB,S,{}]; AcBcont=Complement[AcB,AcBspec];
  Scont=DeleteCases[S,{},1];
  (* collect cooresponding coordinates... *)
  irrcoords=Table[coords[[Scont[[i,j]]]],{i,1,Length[AcBcont]},{j,1,Length[Scont[[i]]]}];
  (* ...and compute associated monomials by taking products *)
  monlst=Table[Outer[Times,Apply[Sequence,irrcoords[[i]]]],{i,1,Length[AcBcont]}];
  (* compute polynomial factors as coefficients of above monomials *)
  pstr=Table[Coefficient[plst[[AcBcont[[i]]]],monlst[[i]]],{i,1,Length[AcBcont]}];
  (* compute pre-factor for map *)
  prefac=sgn*Product[coords[[irrset[[i]],j]],{i,1,Length[irrset]},{j,1,n[[irrset[[i]]]]+1}]
            *Product[plst[[AcBspec[[i]]]],{i,1,Length[AcBspec]}];
  (* compute index sets *)
  Ione=Table[l[irrset[[i]],onelst[[i,j]]],{i,1,Length[irrset]},{j,1,Length[onelst[[i]]]}];
  IS=Table[l[Scont[[i,j]],AcBcont[[i]]],{i,1,Length[AcBcont]},{j,1,Length[Scont[[i]]]}];
  (* compute summation sequence *)
  (* sumseq=Apply[Sequence,Flatten[Table[{Global`l[irrset[[i]],onelst[[i,j]]],1,n[[irrset[[i]]]]+1},{i,1,Length[irrset]},{j,1,Length[onelst[[i]]]}],1]]; *)
  sumseq=Flatten[Table[{l[irrset[[i]],onelst[[i,j]]],1,n[[irrset[[i]]]]+1},{i,1,Length[irrset]},{j,1,Length[onelst[[i]]]}],1];
 (* compute product of polynomial factors *)
  facprod=Product[pol[i,Apply[Sequence,IS[[i]]]],{i,1,Length[AcBcont]}];
  (* compute product of LC tensors *)
  lcprod=Product[\[Epsilon][n[[irrset[[i]]]]+1,Apply[Sequence,Ione[[i]]]],{i,1,Length[irrset]}];
  (* full expression *)
  mapent=facprod*lcprod;
  (* Print[mapent];Print[sumseq];
  Print[pstr]; *)
  For[m=1,m<=Length[sumseq],m++,
    mapent=Sum[mapent,Evaluate[sumseq[[m]]]]/.\[Epsilon][_,___,X_,___,X_,___]->0;
    mapent=mapent/.pol[X__/;VectorQ[{X},IntegerQ]]->Hold[pstr[[X]]]//ReleaseHold;
    (* Print["******* m = ",m];
    Print[mapent]; *)
  ];
  mapent=mapent/.\[Epsilon][i_,X__]->Hold[LeviCivitaTensor[i][[X]]]//ReleaseHold;
  map[[B,A]]=prefac*mapent;

  (* map[[B,A]]=prefac*Sum[facprod*lcprod,Evaluate[sumseq]]/.{Global`pol[X__]->Hold[pstr[[X]]],Global`\[Epsilon][i_,X__]->Hold[LeviCivitaTensor[i][[X]]]}//ReleaseHold; *)

]]]]];

map];


(* ::Subsubsection::Closed:: *)
(* CohLineBBW: Compute cohomology of line bundle on complete intersections*)


Options[CIPro`Private`CohLineBBW]={"OutFormat"->"Coh","Prot"->False};

CIPro`Private`CohLineBBW[lb_List,n_List,nb_List,coords_,plst_,opt___]:=Module[{linmap,symmnum,cicynum,coeffsize,nbT,nP,K,damb,d,NL,p,E1,
E1dim,k,l,kinf,q,pin,qin,pout,qout,din,dout,pos,dlst,Einf,Eprev,d0,ker,map,im,outformat,coh,prot,rkNL,Pind,sublst,meth},

(* options and basic definitions *)
outformat="OutFormat"/.{opt}/.Options[CIPro`Private`CohLineBBW];
prot="CohProt"/.{opt}/.Options[CIPro`Private`CohLineBBW];
nbT=Transpose[nb]; nP=Length[n];K=Length[Transpose[nb]];
damb=Total[n];d=damb-K;
Pind=Table[i,{i,1,K}];

If[prot=="Win",CIPro`Private`InitProt["Calculating cohomology of L="<>ToString[lb]]];

(* compute wedge powers of N^* times L *)
NL=Table[LineTensor[Transpose[{lb}],LineWedge[-nb,p]],{p,0,K}];
sublst=Table[Subsets[Pind,{p}],{p,0,K}];
(* rkNL=Map[Length,Map[Transpose,NL]]; *)

(* create E1 *)
If[prot,Print["-- Compute \!\(\*SubscriptBox[\(E\), \(1\)]\) --"]];
If[prot=="Win",CIPro`Private`WriteProtSt["Compute E1","Subsection"]];
E1=Table[CIPro`Private`CreateBBWList[n,NL[[p+1]],q,coords,"CohInfo"->sublst[[p+1]]],{p,0,K},{q,0,damb}];
E1dim="Dim"/.E1;
If[prot,Print["dim \!\(\*SubscriptBox[\(E\), \(1\)]\) = ",E1dim//MatrixForm]];
If[prot=="Win",CIPro`Private`WriteProt[E1dim//MatrixForm]];

(* set Einfinity to E1 or else iterate spectral sequence *)
Einf=E1;Eprev=E1;k=1;
(* If[kinf>0,Eprev=E1; 
For[k=1,k<=kinf,k++, *)
While[CIPro`Private`contiteration["Dim"/.Einf,k],
  If[prot,Print["-- Compute ",Subscript["E", k+1]," --"]];
  If[prot=="Win",CIPro`Private`WriteProtSt["Compute E"<>ToString[k+1],"Subsection"]];
  For[p=1,p<=K+1,p++,
    For[q=1,q<=damb+1,q++,
      If[("Dim"/.Eprev[[p,q]])>0,
        If[prot,Print["> Compute ",Subscript["E", k+1][p-1,q-1],":"]];
        If[prot=="Win",CIPro`Private`WriteProtSt["Compute E"<>ToString[{k+1,p-1,q-1}],"Subsubsection"]];
        (* If[k>2,meth="dontexpand",meth="expand"]; *) meth="expand";
        pin=p+k;qin=q+k-1;pout=p-k;qout=q-k+1;
        If[pin>0 && pin<=K+1 && qin>0 && qin<=damb+1,din="Dim"/.Eprev[[pin,qin]],din=0];
        If[pout>0 && pout<=K+1 && qout>0 && qout<=damb+1,dout="Dim"/.Eprev[[pout,qout]],dout=0];
        (* first compute ker of outgoing map *)
        If[dout==0,ker=Eprev[[p,q]],
          map=CIPro`Private`KoszulMap[n,lb,nb,p-1,q-1,k,coords,plst,opt];
          ker=CIPro`Private`MapBBWList[Eprev[[p,q]],Eprev[[pout,qout]],map,"Meth"->meth,"OutFormat"->"Ker",opt]];
          If[prot,Print["dim Ker(",Subscript["E", k][p-1,q-1]," --> ",Subscript["E", k][pout-1,qout-1],") = ","Dim"/.ker]];
          If[prot=="Win",CIPro`Private`WriteProtSt["dim Ker(E"<>ToString[{k,p-1,q-1}]<>" --> E"<>ToString[{k,pout-1,qout-1}]<>") = "<>ToString["Dim"/.ker],"Output"]];
        (* now compute image of ingoing map and take quotient *)
        If[din==0,Einf[[p,q]]=ker;If[prot=="Win",CIPro`Private`WriteProtSt["dim Im(E"<>ToString[{k,pin-1,qin-1}]<>" --> E"<>ToString[{k,p-1,q-1}]<>") = 0","Output"]];
          If[prot,Print["dim Im(",Subscript["E", k][pin-1,qin-1]," --> ",Subscript["E", k][p-1,q-1],") = 0"]],
          map=CIPro`Private`KoszulMap[n,lb,nb,pin-1,qin-1,k,coords,plst,opt];
          im=CIPro`Private`MapBBWList[Eprev[[pin,qin]],Eprev[[p,q]],map,"Meth"->meth,"OutFormat"->"Im",opt];
          If[prot=="Win",CIPro`Private`WriteProtSt["dim Im(E"<>ToString[{k,pin-1,qin-1}]<>" --> E"<>ToString[{k,p-1,q-1}]<>") = "<>ToString["Dim"/.im],"Output"]];
          If[prot,Print["dim Im(",Subscript["E", k][pin-1,qin-1]," --> ",Subscript["E", k][p-1,q-1]," = ","Dim"/.im]];
          Einf[[p,q]]=CIPro`Private`QuotientBBW[ker,im,opt];
          If[prot=="Win",CIPro`Private`WriteProtSt["dim E"<>ToString[{k+1,p-1,q-1}]<>" = "<>ToString["Dim"/.Einf[[p,q]]],"Output"]];
          If[prot,Print["dim ",Subscript["E", k+1][p-1,q-1]," = ","Dim"/.Einf[[p,q]]]]]]]];
   Eprev=Einf; k++;
   If[prot=="Win",CIPro`Private`WriteProt[MatrixForm["Dim"/.Einf]]];
   If[prot,Print[Subscript["dim E", k]," = ",MatrixForm["Dim"/.Einf]]]];
If[prot,Print["--  \!\(\*SubscriptBox[\(E\), \(\[Infinity]\)]\) = ",Subscript["E", k],"  --"]];
If[prot=="Win",CIPro`Private`WriteProtSt["Einfinity = E"<>ToString[k],"Subsubsection"]];

(* for appropriate output format return Einf *)
If[outformat=="Einf",Return[Einf]];

(* for cohomology output format form diagonal direct sums and return these *)
If[outformat=="Coh",
  coh=Map[CIPro`Private`DirectSumBBW,Table[Einf[[p,p+k]],{k,0,d},{p,1,K+1}]];
  If[prot=="Win",CIPro`Private`WriteProtSt["Cohomology: "<>ToString["Dim"/.coh],"Subsection"]];
  Return[coh]]];


(* check if further iteration is required *)
CIPro`Private`contiteration[Edim_,k_]:=Module[{pos,X,dlst},
pos=Position[Edim,X_/;X>0];
dlst=Select[Flatten[Outer[Plus,pos,-pos,1,1],1],#[[1]]-#[[2]]==1&];
Max[Map[First,dlst]]>=k];


(* ::Subsubsection::Closed:: *)
(* CohLinesBBW: Compute cohomology of line bundle sums on complete intersections*)


Options[CIPro`Private`CohLinesBBW]={"CohProt"->False};

CIPro`Private`CohLinesBBW[lbsum_List,n_List,nb_List,coords_,plst_,opt___]:=Module[{lbst,cohlst,i,prot,cohlstm},

(* options *)
prot="CohProt"/.{opt}/.Options[CIPro`Private`CohLinesBBW];
lbst=Transpose[lbsum];

(* compute cohomology of each line bundle *)
cohlst={};
For[i=1,i<=Length[lbst],i++,
  If[prot,Print["L = \!\(\*SubscriptBox[\(O\), \(X\)]\)(",lbst[[i]],")"]];
  cohlst=Append[cohlst,CIPro`Private`CohLineBBW[lbst[[i]],n,nb,coords,plst,"OutFormat"->"Coh",opt]]];

Transpose[cohlst]];


(* ::Subsection::Closed:: *)
(*Protocol modules*)


(* ::Subsubsection::Closed:: *)
(*InitProt*)


(* initialise protocol *)
CIPro`Private`InitProt[s_]:=Module[{nbl},

CIPro`Private`ProtNum=0;
If[$Notebooks,
   nbl=Notebooks["Cicy protocol"];
   If[Length[nbl]>0,CIPro`Private`EvalNote=nbl[[1]],
      CIPro`Private`EvalNote=NotebookCreate[WindowTitle -> "Cicy protocol", WindowSize -> {500, 800}]];
   NotebookWrite[CIPro`Private`EvalNote,Cell[s,"Section"]],
   WriteString["stdout",s]]];


(* ::Subsubsection::Closed:: *)
(*WriteProt*)


(* write entry into a protocol window *)
CIPro`Private`WriteProt[expr_]:=Module[{p},

CIPro`Private`ProtNum=CIPro`Private`ProtNum+1;
If[$Notebooks,
  NotebookWrite[CIPro`Private`EvalNote,RowBox[{Cell[BoxData[ToBoxes[expr]],FontSize->10,FontWeight->"Plain",TextAlignment->-1]}]];
  SelectionMove[CIPro`Private`EvalNote,Next,Cell],
WriteString["stdout",ToString[CIPro`Private`ProtNum]<>", "]]];


(* ::Subsubsection::Closed:: *)
(*WriteProtSt*)


CIPro`Private`WriteProtSt[s_,sec_]:=Module[{},
CIPro`Private`ProtNum=CIPro`Private`ProtNum+1;
If[$Notebooks,
 NotebookWrite[CIPro`Private`EvalNote,Cell[s,sec]],
   WriteString["stdout",s]]];


(* ::Subsubsection::Closed:: *)
(*CleanProt*)


(* remove protocol *)
CIPro`Private`CleanProt[s_]:=Module[{},
If[$Notebooks,
   SelectionMove[CIPro`Private`EvalNote,After,Cell];
   NotebookWrite[CIPro`Private`EvalNote,Cell[BoxData[s],FontFamily->"Times",FontSize -> 10, FontColor -> RGBColor[0.5, 0, 0],FontWeight -> "Plain"]]]];


(* ::Section::Closed:: *)
(*Main package modules*)


(* ::Subsection::Closed:: *)
(*CIExample: Access examples for how to use the package*)


CIPro`CIExample::usage="CIExample[string], gives access to examples for how to use the package. These examples appear in the notebook in use, or a separate notebook, and they can be executed directly.\n"<>
"\[FilledSmallSquare] CIExample[] prints a list of available examples in the form name: info.\n"<>
"\[FilledSmallSquare] CIExample[topic] prints a list of all available examples which cover the given topic.\n"<>
"\[FilledSmallSquare] CIexample[exname] opens the example with the given name in a new notebook. Options:\n"<>
"\[FilledSmallSquare] \"Window\"->Boolean, opens example in new window if True, otherwise displays in current notebook (default).";

Options[CIExample]:={"Window"->True};

CIExample[exname_:None,opt___]:=Module[{path,exlst,i,str,namelst,ex,exlst1,fn,nb,nb2,win,cells,cellStyle,codeStyles,outputStyles,sanitizeCell,cells2,sectionLevel,kind,finalizeNode,buildSectionGroups,nbk},

(* basic definitions *)
path="ExamplePath"/.Options[CIPro];
exlst=ReadList[path<>"ExampleList.m"];
win="Window"/.{opt}/.Options[CIExample];
namelst=Map[First,exlst];
ex=ToString[exname];

(* if an example name is given open this example *)
If[MemberQ[namelst,ex],
  nb=Get[path<>ex<>".nb"]; 
  
(*Code to avoid formatting problems in importing examples*)

(* --- 1. extract cells from the imported notebook --- *)
cells = Replace[nb, {
  Notebook[c_List, ___] :> c,
  c_List :> c,
  _ :> {}
}];

(* --- 2. unwrap any Cell[CellGroupData[...], ...] wrappers --- *)
cells = Flatten @ (cells /. Cell[CellGroupData[g_List, ___], ___] :> Sequence @@ g);

(* --- 3. define helpers for style classification --- *)
cellStyle[c_Cell] := ToString @ Replace[Quiet @ c[[2]], {Except[_String] -> "Text"}];

codeStyles   = {"Input","Code","Program"};
outputStyles = {
  "Output","Print","Message","Echo","Info","Warning","Error",
  "Graphics","OutputSizeLimit","PrintTemporary"
};

(* --- 4. sanitize cells: convert outputs to Text, freeze headings/text --- *)
sanitizeCell[c_Cell] := Module[{sty = cellStyle[c]},
  Which[
    MemberQ[codeStyles, sty],
      c,

    MemberQ[outputStyles, sty],
      c /. Cell[ct_, _s _, opts___] :>
        With[{ol = {opts}},
          Cell[
            ct, "Text",
            Sequence @@ DeleteCases[ol, (GeneratedCell | CellAutoOverwrite | CellLabel) -> _],
            GeneratedCell     -> False,
            CellAutoOverwrite -> False,
            CellDeletable     -> False
          ]
        ],

    True,
      c /. Cell[ct_, s_, opts___] :>
        With[{ol = {opts}},
          Cell[
            ct, s,
            Sequence @@ DeleteCases[ol, (GeneratedCell | CellAutoOverwrite | CellLabel) -> _],
            GeneratedCell     -> False,
            CellAutoOverwrite -> False,
            CellDeletable     -> False
          ]
        ]
  ]
];

cells2 = sanitizeCell /@ cells;

(* --- 5. section hierarchy builder --- *)
sectionLevel[s_] := Switch[s,
  "Title", 0, "Subtitle", 0, "Subsubtitle", 0,
  "Section", 1, "Subsection", 2, "Subsubsection", 3,
  _, Infinity
];

kind[c_Cell] := If[MemberQ[codeStyles, cellStyle[c]], "code", "text"];

finalizeNode[hdr_Cell, body_List] := Module[{runs, subgroups},
  runs = SplitBy[body, kind];
  subgroups = CellGroupData[#, Open] & /@ Select[runs, Length[#] > 0 &];
  CellGroupData[Prepend[subgroups, hdr], Open]
];

buildSectionGroups[c_List] := Module[{stack = {}, out = {}, cel, lvl, s, hdr, bod},
  Do[
    cel = c[[i]]; s = cellStyle[cel]; lvl = sectionLevel[s];
    If[lvl =!= Infinity,
      (* close same-or-deeper sections *)
      While[stack =!= {} && Last[stack][[1]] >= lvl,
        {hdr, bod} = Last[stack][[2 ;; 3]];
        out = Append[If[Length[stack] > 1,
                        stack[[-2, 3]] = Append[stack[[-2, 3]], finalizeNode[hdr, bod]];
                        out,
                        Append[out, finalizeNode[hdr, bod]]
                      ], Sequence @@ {}];
        stack = Most[stack];
      ];
      AppendTo[stack, {lvl, cel, {}}],
      (* non-header: append to body of current section or top-level *)
      If[stack === {}, AppendTo[out, cel], AppendTo[stack[[-1, 3]], cel]]
    ],
    {i, Length[c]}
  ];
  
  (* close remaining open sections *)
  While[stack =!= {},
    {hdr, bod} = Last[stack][[2 ;; 3]];
    out = Append[If[Length[stack] > 1,
                    stack[[-2, 3]] = Append[stack[[-2, 3]], finalizeNode[hdr, bod]];
                    out,
                    Append[out, finalizeNode[hdr, bod]]
                  ], Sequence @@ {}];
    stack = Most[stack];
  ];
  (* wrap stray text/code runs at top level *)
  out = out /. l_List :> (CellGroupData[#, Open] & /@ SplitBy[l, kind]);
  Flatten[out]
];

nb = buildSectionGroups[cells2];

(*End of code to deal with formating issues*)
  
  If[win,
    fn=NotebookDirectory[]<>ex; 
    
  With[{doc = CreateDocument[{}, NotebookFileName -> fn]},
  NotebookDelete @ Cells[doc];                  (* drop the placeholder cell, if any *)
  SelectionMove[doc, After, Notebook];          (* ensure top-level insertion point *)
  Scan[
    (NotebookWrite[doc, #]; SelectionMove[doc, After, Cell]) &,
    nb
  ];
  doc
]
    ,
    
(* write all prepared groups right AFTER the calling cell, as real groups *)
nbk = EvaluationNotebook[];
SelectionMove[nbk, After, Cell];                 (* <-- after the cell that ran CIExample *)
Scan[
  (NotebookWrite[nbk, #]; SelectionMove[nbk, After, Cell]) &,
  nb                                            (* nb is your list of CellGroupData[...] *)
];
  ];  
  Return[];
];

(* otherwise selsec all examples or examples where given topic arises *)
If[exname===None,
  InfoPrint[CIPro`CIExample::usage];
  exlst1=exlst; str="List of Examples (execute CIExample[name] for more info:\n",
  exlst1=Select[exlst,Apply[Or,StringContainsQ[#[[2]],ex]]&];
  str="Examples with tags containing "<>ex<>" (execute CIExample[name] for more info:\n";
];  

(* print selected examples *)
For[i=1,i<=Length[exlst1],i++,
 str=str<>"\""<>exlst1[[i,1]]<>"\": "<>exlst1[[i,3]];
 If[i<Length[exlst1],str=str<>"\n"]];
 InfoPrint[str];
 Return[];
];


(* ::Subsection::Closed:: *)
(*Data modules*)


(* ::Subsubsection::Closed:: *)
(*Help for data modules*)


CIPro`CIDataModules::usage="Package data can be processed with the following modules (see ?modulename for details):\n"<>
"\[FilledSmallSquare] Data: loads in package data.\n"<>
"\[FilledSmallSquare] SaveData: saves data as new package data.\n"<>
"\[FilledSmallSquare] DeleteData: delete package data.";



(* ::Subsubsection::Closed:: *)
(*Data: load and search data*)


CIPro`Data::usage="Data[<dataname>,<cond>,<keys>], provides convenient access to the package data.\n"<>
"\[FilledSmallSquare] Data[] displays geneal help and the names of all datasets available.\n"<>
"\[FilledSmallSquare] Data[dataname] diplays information about the data set with the given name.\n"<>
"\[FilledSmallSquare] Data[dataname,cond] extracts parts of the dataset. The possible choice for the argument cond are as follows:\n"<>
"  \[Bullet] integer: the entry with this index is returned.\n"<>
"  \[Bullet] list of two integers: the entries in this range are returned.\n"<>
"  \[Bullet] All: the entire data set is returned.\n"<>
"  \[Bullet] \"Length\": the length of the data set is returned.\n"<>
"  \[Bullet] Boolean function: all entries for which the function is true are returned.\n"<>
"\[FilledSmallSquare] Data[dataname,cond,keys] finds the associations which satisfy the condition and extrscts the parts specified by keys (a key or a list of keys).";

Data[dataname_String:"",cond_:None,keylst_:{}]:=Module[{path,fname,paths,dnames,sel,X,Y,range,data,keys},

(* options *)
path="DataPath"/.Options[CIPro];
If[!DirectoryQ[path],Message[CIPro::dirmissing]; Return[]];
(* keys="Keys"/.{opt}/.Options[Data]; *) keys=Flatten[{keylst}];

(* check if a dataname is given *)
If[StringLength[dataname]==0,
   InfoPrint[CIPro`Data::usage];
   (* if no dataname is given return a list of viable names *)
   paths=Select[FileNames[All,path],!StringContainsQ[#,"."]&];
   dnames=Map[Last[FileNameSplit[#]]&,paths];
   InfoPrint["Available data sets: "<>ToString[dnames]]; Return[],
   (* if dataname is given with no further option diplay info *)
   If[cond===None,
     If[KeyExistsQ[CIPro`DataInfo,dataname],InfoPrint["Info on data "<>dataname<>": "<>CIPro`DataInfo[dataname]],
                                           Message[CIPro::datamissing,dataname]];
     Return[]
   ];
   If[cond==="String",
     If[KeyExistsQ[CIPro`DataInfo,dataname],Print[CIPro`DataInfo[dataname]],
                                           Message[CIPro::datamissing,dataname]];
     Return[]
   ];
     (* if an option exists, check if data set has already been loaded in *)
     If[!KeyExistsQ[CIPro`CIData,dataname],
       fname=path<>dataname; 
       If[!FileExistsQ[fname],Message[CIPro::datamissing,dataname]; Return[],
         Get[fname]; AssociateTo[CIPro`CIData,dataname->CIPro`CILoad];
         InfoPrint["Data set "<>dataname<>" loaded."];
       ];  
      ];   
     (* if an integer is given return this element of data set *)
     If[IntegerQ[cond],
       If[cond>0 && cond<=Length[CIPro`CIData[dataname]],sel=CIPro`CIData[dataname][[cond]],
         Message[CIPro::listbounds,dataname,Length[CIPro`CIData[dataname]]]; Return[];
       ],  
       (* Length of data set *)
       If[cond==="Length",Return[Length[CIPro`CIData[dataname]]]];
       (* return all of data set *)
       If[cond===All,sel=CIPro`CIData[dataname], 
         (* if a range is given return the corresponding entries *)
         If[VectorQ[cond,IntegerQ]&& Length[cond]==2,
           range=Sort[cond];
           If[range[[1]]<1,range[[1]]=1];
           If[range[[2]]>Length[CIPro`CIData[dataname]],range[[2]]=Length[CIPro`CIData[dataname]]];
           sel=Take[CIPro`CIData[dataname],range],
           (* finally, assume a conditional expression has been given *) 
           sel=Select[CIPro`CIData[dataname],cond];
         ];  
       ];
     ];    
 ];    

Switch[Length[keys],
  0,sel,
  1,Map[Lookup[#,First[keys]]&,Flatten[{sel},1]],
  _,Map[Lookup[#,keys]&,Flatten[{sel},1]]
]
];


(* ::Subsubsection::Closed:: *)
(*SaveData: save data set*)


CIPro`SaveData::usage="SaveData[data_List,dataname_String,datainfo_String], saves the data (a list of associations) under the given name and with the info provided.";

SaveData[data_List:{},name_String:"",info_String:""]:=Module[{path,datanames,fpath,ipath},

If[data==={},InfoPrint[CIPro`SaveData::usage];Return[]];
(* error checking *)
path="DataPath"/.Options[CIPro];
If[!DirectoryQ[path],Message[CIPro::dirmissing]; Return[]];
If[!Apply[And,Map[AssociationQ,data]],Message[CIPro::dataformat]; Return[]];
datanames=Keys[CIPro`DataInfo];
If[MemberQ[datanames,name],Message[CIPro::nametaken]; Return[]];

(* write data *)
fpath=path<>name; CIPro`CILoad=data;
Print[fpath];
DumpSave[fpath,CIPro`CILoad];

(* add info *)
ipath=path<>"DataInfo.txt";
AssociateTo[CIPro`DataInfo,name->info];
Put[CIPro`DataInfo,ipath];
InfoPrint["Data set "<>name<>" saved."];
(* Data[]; *)
];


(* ::Subsubsection::Closed:: *)
(*DeleteData: delete data set*)


CIPro`DeleteData::usage="DeleteData[dataname_String], deletes the named data set.";

DeleteData[name_String:""]:=Module[{path,datanames,fpath,ipath,resp},

If[name==="",InfoPrint[CIPro`DeleteData::usage]; Return[]];
(* error checking *)
path="DataPath"/.Options[CIPro]; fpath=path<>name;
datanames=Keys[CIPro`DataInfo];
If[!FileExistsQ[fpath],Message[CIPro::datamissing,name]; Data[]; Return[]];
resp=Input["Do you really want to delete data set \""<>name<>"\"? yes/no"]//ToString;
If[resp!="yes",InfoPrint["Nothing deleted"]; Return[]];

(* delete data *)
DeleteFile[fpath];

(* delete info on data set *)
ipath=path<>"DataInfo.txt";
CIPro`DataInfo=KeyDrop[CIPro`DataInfo,name];
Put[CIPro`DataInfo,ipath];
InfoPrint["Data set "<>name<>" deleted."];
(* Data[]; *)
];


(* ::Subsection::Closed:: *)
(*CICheck: check an association*)


CIPro`CICheck::usage="CICheck[ass,opt] to check an association for consistency.\n"<>
"\[FilledSmallSquare] Options \"Check\"->string set the level of the check. For \"Medium\" only consistency of keys is checked, for \"Full\" also consistency of values.\n"<>
"\[FilledSmallSquare] True is returned if association is consistent or has non-fatal inconsistencies, False otherwise.";

Options[CICheck]:={"Check"->"Medium"};

CICheck[ass_:{},opt___]:=Module[{check,plstass,plst,keysunknown,i,prop,pmissing,keysknown},

If[ass==={},InfoPrint[CIPro`CICheck::usage]; Return[]];
(* options *)
check="Check"/.{opt}/.Options[CICheck];

(* basic checks *)
If[!AssociationQ[ass],Message[CIPro::noass]; Return[False]];
If[!KeyExistsQ[ass,"Conf"],Message[CIPro::noconf,"Conf"]; Return[False]];

(* extract keys and check if all keys are known *)
If[!KeyExistsQ[ass,"Num"] && !KeyExistsQ[ass,"Degree"],
  plstass=Keys[ass]; plst=Keys[CIPro`Private`CIProMod];
  keysunknown=Complement[plstass,plst]; keysknown=Complement[plstass,keysunknown];
  If[Length[keysunknown]>0,Message[CIPro::wrongkeys,keysunknown]];

(* check if for every key the keys of dependencies are present *)

  For[i=1,i<=Length[keysknown],i++,
    prop=keysknown[[i]];
    pmissing=Complement[CIPro`Private`CIProDep[prop],keysknown];
    If[Length[pmissing]>0,Message[CIPro::depmissing,pmissing,prop]];
  ]; 
]; 
  
True];


(* ::Subsection::Closed:: *)
(*CIProp: Universal wrapper module for CI properties and related structures*)


CIPro`CIProp::usage="CIProp[<ass>,<proplst>,opt], computes the properties in proplst for the given association and adds them to the association.\n"<>
"\[FilledSmallSquare] CIProp[] produces a help for CIProp, including a list of options and available properties.\n"<>
"\[FilledSmallSquare] CIProp[\"Long\"] produces a long help for CIProp, including a list of available properties, a list of options and mathematical background.\n"<>
"\[FilledSmallSquare] CIProp[\"Options\"] produces a list of options.\n"<>
"\[FilledSmallSquare] CIProp[\"Keys\"] produces a list of available properties.\n"<>
"\[FilledSmallSquare] CIProp[propkey], produces a short help message explaining the meaning of the property with this key.\n"<>
"\[FilledSmallSquare] CIProp[propkey,\"Long\"] produces a longer explanation with mathematical background and an example, if available.\n"<>
"\[FilledSmallSquare] CIProp[ass] produces a message with the properties not yet computed for the association.\n"<>
"\[FilledSmallSquare] CIProp[ass,proplst], computes all properties listed in proplst.\n"<>
"\[FilledSmallSquare] Entries of proplst must be strings of the form \"property\", leading to a new association entry of the form \"property\"->value.\n"<>
"\[FilledSmallSquare] Dependencies of properties are automatically taken into account, that is, if the computation of a particular property is requested all properties it relies on are computed (and added to the association) as well.";

CIPro`CIPropOptions::usage="The options for module CIProp are:\n"<>
"\[FilledSmallSquare] The output depends on the \"Format\"->string option, with values \"Full\", \"Medium\" and \"Short\".\n"<>
"\[FilledSmallSquare] Further options are:\n"<>
"\[FilledSmallSquare] \"CoordName\"->symbol, to specify the symbol used for homogenous coordinates.\n"<>
"\[FilledSmallSquare] \"CoeffRange\"->{min,max}, to specify the range of coefficients used for \"DefEqs\".\n"<>
"\[FilledSmallSquare] \"CoeffType\"->symbol, to specify the type of coefficient in \"DefEqs\" with choices \"Integer\", \"Real\", \"CInteger\", \"CReal\" or a symbol for symbolic coefficients.\n"<>
"\[FilledSmallSquare] \"MaxDeg\"->integer, specifies the maximal degree up to which GV invariants are computed in \"GVInv\".\n"<>
"\[FilledSmallSquare] \"HilbertFormat\"->format, where the default {} gives the closed form, an integer the expansion up to this total degree and an integer vector the expansion up to this multi-degree.\n"<>
"\[FilledSmallSquare] \"CohQ->q, specifies which cohomology \!\(\*SuperscriptBox[\(H\), \(q\)]\)(L) of a line bundle L, or, for q={\!\(\*SubscriptBox[\(q\), \(1\)]\),...,\!\(\*SubscriptBox[\(q\), \(r\)]\)), which cohomologies \!\(\*SuperscriptBox[\(H\), SubscriptBox[\(q\), \(a\)]]\)(\!\(\*SubscriptBox[\(L\), \(a\)]\)) of a line bundle sum \!\(\*SubscriptBox[\(L\), \(1\)]\)+...+\!\(\*SubscriptBox[\(L\), \(r\)]\) are computed (default 0).\n"<>
"\[FilledSmallSquare] \"FieldChar\"->integer, to specify the character of a finite field (default 101).\n"<>
"\[FilledSmallSquare] \"CohInfo\"->list, to specify some auxiliary properties of cohomology (default {}).\n"<>
"\[FilledSmallSquare] \"Eqs\"->list of polynomials, to specify a list of definining equations for the CI.";

CIProp[ass_:All,proplst_:{},opt___]:=Module[
  {plst,outformat,assnew,plst0,key,code,i,newvalue,res,plstf,keys,str,asskeys,j,plstf1,section,wlst,path,fn,nb},

(* options and definitions *)
outformat="Format"/.{opt}/.Options[CIProp];
plst0=Keys[CIPro`Private`CIProMod]; plstf=Select[Flatten[{proplst}],StringQ[#]&]; 
path=("ExamplePath"/.Options[CIPro])<>"SmallExamples/";
(* find keys in association *)
If[AssociationQ[ass], 
    str="Keys not yet computed (execute CIProp[key] for more info):\n"; asskeys=Keys[ass],
    str="Available keys (execute CIProp[key] for more info):\n"; asskeys={};
  ];
keys=Keys[CIPro`Private`CIProSection]; 
(* compose information on keys either missing ones or all of them *)
For[i=1,i<=Length[keys],i++,key=keys[[i]];
    section=Complement[CIPro`Private`CIProSection[key],asskeys];
    If[Length[section]>0,
      str=str<>key<>": "<>ToString[section];
      If[i<Length[keys],str=str<>"\n"];
    ];  
];  

(* print out available keys *)
If[ass===All || ass==="Long" || (AssociationQ[ass]&& Length[plstf]==0),
  InfoPrint[CIPro`CIProp::usage];
  InfoPrint[str];
  InfoPrint[CIPro`CIPropOptions::usage];
  If[ass==="Long",
    For[i=1,i<=Length[CIPro`MathGeneralInfo],i++,
        Print[Framed[CIPro`MathGeneralInfo[[i]],ImageSize->900,Background->RGBColor[0.96,0.99,1]]]];
  ];    
  Return[];
];    
If[StringQ[ass],
  Switch[ass,
         "Options",InfoPrint[CIPro`CIPropOptions::usage],
         "Keys",InfoPrint[str],
         "Short",InfoPrint[CIPro`CIPropOptions::usage],
         _,If[MemberQ[plst0,ass],HelpPrint[ass,proplst],
           Message[CIPro::wrongkeys,ass]];  
        ];   
  Return[];
];

(* some more error messages *)
(* If[!CICheck[ass,"Check"->"Medium"],Return[]]; *)

(* prepare dependencies *)
res=<||>; assnew=ass; 
For[j=1,j<=Length[plstf],j++,plstf1={plstf[[j]]};                                                                                      
  plst=Intersection[plstf1,plst0]; 
  wlst=Complement[plstf,plst0];
  If[Length[wlst]>0,Message[CIPro::wrongkeys,wlst]];
  plst=Join[plst,Flatten[Lookup[CIPro`Private`CIProDep,plst]]];
  plst=Sort[plst,FreeQ[CIPro`Private`CIProDep[#1],#2]&]//DeleteDuplicates;

(* call modules to compute properties *)
  For[i=1,i<=Length[plst],i++,
    key=plst[[i]];
    If[!KeyExistsQ[assnew,key],
      code=CIPro`Private`CIProMod[key]; newvalue=Quiet[Check[code[assnew,opt],$Failed]];
      If[newvalue===$Failed,Message[CIPro::badass]; Return[]];
      If[AssociationQ[newvalue],assnew=Join[assnew,newvalue]; res=Join[res,newvalue],
        AssociateTo[assnew,key->newvalue]; AssociateTo[res,key->newvalue]];
    ]; 
  ];  
];

(* output *)
Switch[outformat,
  "Full",assnew,
  "Medium",res,
  _,Last[res]
]]; 


(* ::Subsection::Closed:: *)
(*CIMod: Universal wrapper for modifying CI associations*)


CIPro`CIMod::usage="CIMod[<asslst>,opkey,opt]creates new structures from given ones.\n"<>
"\[FilledSmallSquare] asslst is an association or a list of associations, opkey a string which refers to the operation.\n"<>
"\[FilledSmallSquare] CIMod[] produces a short help message for CIMod which includes a list of available operations.\n"<>
"\[FilledSmallSquare] CIMod[\"Long\"] produces a long help message for CIMod which includes a list of available operations, a list of options and mathematical background.\n"<>
"\[FilledSmallSquare] CIMod[\"Options\"] produces a list of options.\n"<>
"\[FilledSmallSquare] CIMod[\"Keys\"] produces a list of operation keys.\n"<>
"\[FilledSmallSquare] CIMod[opkey], provides basic information about the operation with the given key.\n"<>
"\[FilledSmallSquare] CIMod[opkey,\"Long\"], provides basic information, together with more detailed mathematical information and an executable example (if available), about the operation with the given key.\n"<>
"\[FilledSmallSquare] CIMod[asslst,opkey], applies the operation opkey to asslst.";

CIPro`CIModOptions::usage="Options for module CIMod are:\n"<>
"\[FilledSmallSquare] The output depends on the \"Format\"->string option, with values \"Full\", \"Medium\" and \"Short\".\n"<>
"\[FilledSmallSquare] \"TensorPower\"->integer, to specify the symmetric or wedge power to be carried out on line bundle sums (default 2).\n"<>
"\[FilledSmallSquare] \"Map\"->matrix of polynomials, to specify a map between cohomologies for operation \"MapSpaceLBS\".\n"<>
"\[FilledSmallSquare] \"Space\"->string, to specify the type of space, \"Ker\" (default), \"Im\" or \"Coker\", computed by \"MapSpaceLBS\".\n"<>
"\[FilledSmallSquare] \"Modulus\"->integer, to specify the characteristic of the field over which cohomology calculations are carried out (default 0).\n"<>
"\[FilledSmallSquare] \"Ekpq\"->list {k,p,q} of integers, to specify the map \!\(\*SuperscriptBox[\(H\), \(q\)]\)(A,\!\(\*SuperscriptBox[\(\[CapitalLambda]\), \(p\)]\)\!\(\*SuperscriptBox[\(N\), \(*\)]\)\[Times]L) -> \!\(\*SuperscriptBox[\(H\), \(q - k + 1\)]\)(A,\!\(\*SuperscriptBox[\(\[CapitalLambda]\), \(p - k\)]\)\!\(\*SuperscriptBox[\(N\), \(*\)]\)\[Times]L), computed by \"KoszulLBS\".\n"<>
"\[FilledSmallSquare] \"CohProt\"->value, default False, if True prints a protocal of the cohomology calculation into the notebook, if set to \"Win\" the protocal is printed into a separate notebook.\n"<>
"\[FilledSmallSquare] \"CohFormat\"->string, sets the output level for cohomology results from \"CohLBS\". If set to \"Dim\" (default) only cohomology dimensions will be returned, otherwise the full cohomology representations.\n"<>
"\[FilledSmallSquare] \"CohSum\"->Boolean, if False (default) cohomology for line bundle sums will be returned for each line bundle, otherwise, as a sum over all line bundles.\n"<>
"\[FilledSmallSquare] \"CoeffRange\"->range, gives the range from which random coefficients in polynomials etc. are being drawn (default {1,100}.\n"<>
 "\[FilledSmallSquare] \"CoeffType\"->string, type of random coefficients. Choices are \"Integer\" (default), \"Raional\", \"Real\" and \"Complex\".";


CIMod[ass_:All,mod_:"",opt___]:=Module[
  {outformat,plst0,mods,str,keys,key,i,deplst,missingkeys,assnew,code,assextra,assout,
   sections,asscommon,assextraf,asslst,asslst1,fn,path,nb},

(* options and definitions *)
outformat="Format"/.{opt}/.Options[CIMod];
plst0=Keys[CIPro`Private`CIModMod]; mods=ToString[mod]; 
path=("ExamplePath"/.Options[CIPro])<>"SmallExamples/";
str="Available keys (execute CIProp[key] for more info):\n";
sections=Select[CIPro`Private`CIModSection,Length[#]>0&]; keys=Keys[sections];
For[i=1,i<=Length[keys],i++,key=keys[[i]];
    str=str<>key<>": "<>ToString[sections[key]];
    If[i<Length[keys],str=str<>"\n"];     
];

(* print out some help *)
Switch[ass,
         "Options",InfoPrint[CIPro`CIModOptions::usage]; Return[],
         "Keys",InfoPrint[str]; Return[],
         "Short",InfoPrint[CIPro`CIModOptions::usage]; Return[],
         All, InfoPrint[CIPro`CIMod::usage]; InfoPrint[str]; InfoPrint[CIPro`CIModOptions::usage]; Return[],
         "Long", InfoPrint[CIPro`CIMod::usage]; InfoPrint[str]; InfoPrint[CIPro`CIModOptions::usage];
           For[i=1,i<=Length[CIPro`MathGeneralInfo],i++,
             Print[Framed[CIPro`MathGeneralInfo[[i]],ImageSize->900,Background->RGBColor[0.96,0.99,1]]]]; Return[]
       ];  
 
(* print out available modifications *)   
If[StringQ[ass],
  If[MemberQ[plst0,ass],HelpPrint[ass,mod],
  Message[CIPro::wrongkeys,ass]];
  Return[];
];

(* check CI *)
asslst=Flatten[{ass}];
If[!Apply[And,Map[CICheck[#,"Check"->"Medium"]&,asslst]],Return[]];

(* check if association contains all required keys *)
If[FreeQ[plst0,mods], Message[CIPro::wrongkeys,mods];Return[]];
deplst=CIPro`Private`CIModDep[mod]; asslst1={}; 
For[i=1,i<=Length[asslst],i++,
  missingkeys=Complement[deplst,Keys[asslst[[i]]]];
  If[Length[missingkeys]>0,
    assnew=CIProp[asslst[[i]],missingkeys,opt],
    assnew=asslst[[i]]
  ];
  (* asslst1=Append[asslst1,KeySelect[assnew,MemberQ[deplst,#]&]]; *)
  asslst1=Append[asslst1,assnew];
];

(* compute modification *)
code=CIPro`Private`CIModMod[mod];
assout=Quiet[Check[code[asslst1,opt],$Failed]];
If[assout===$Failed, Message[CIPro::badass]; Return[]];

assout]; 


(* ::Section::Closed:: *)
(*End Package*)


End[]
EndPackage[]
